import React, { useState, useEffect } from "react";
import { Copy, ArrowRight, Activity, Zap, Layers, RefreshCw } from "lucide-react";

interface CalculatorsProps {
  onExportToChat: (text: string) => void;
}

export default function Calculators({ onExportToChat }: CalculatorsProps) {
  const [activeTab, setActiveTab] = useState<
    "ohms" | "divider" | "beam" | "vibration" | "reynolds" | "carnot"
  >("ohms");

  // --- State for Ohm's Law ---
  const [ohmsSolveFor, setOhmsSolveFor] = useState<"V" | "I" | "R">("V");
  const [ohmsV, setOhmsV] = useState(12);
  const [ohmsI, setOhmsI] = useState(2);
  const [ohmsR, setOhmsR] = useState(6);

  // --- State for Voltage Divider ---
  const [divVin, setDivVin] = useState(10);
  const [divR1, setDivR1] = useState(1000);
  const [divR2, setDivR2] = useState(2000);

  // --- State for Beam Deflection ---
  const [beamLoad, setBeamLoad] = useState(5000); // P (Newtons)
  const [beamLength, setBeamLength] = useState(6); // L (meters)
  const [beamE, setBeamE] = useState(200); // Young's modulus (GPa) -> steel
  const [beamI, setBeamI] = useState(150); // Moment of inertia (* 10^-6 m^4)

  // --- State for Vibration ---
  const [vibM, setVibM] = useState(10); // Mass (kg)
  const [vibK, setVibK] = useState(1000); // Spring Constant (N/m)
  const [vibC, setVibC] = useState(50); // Damping value (N·s/m)

  // --- State for Reynolds Number ---
  const [reyV, setReyV] = useState(1.5); // velocity (m/s)
  const [reyD, setReyD] = useState(0.1); // pipe diameter (m)
  const [reyRho, setReyRho] = useState(1000); // density (kg/m³) -> Water
  const [reyMu, setReyMu] = useState(0.001); // dynamic viscosity (Pa·s)

  // --- State for Carnot Cycle ---
  const [carTh, setCarTh] = useState(600); // hot reservoir (Kelvin)
  const [carTc, setCarTc] = useState(300); // cold reservoir (Kelvin)

  // Feedback triggers for copy buttons
  const [copiedStatus, setCopiedStatus] = useState<string | null>(null);

  const showCopyMessage = (key: string) => {
    setCopiedStatus(key);
    setTimeout(() => setCopiedStatus(null), 2000);
  };

  // --- Calculations ---

  // Ohm's Law
  const calculateOhms = () => {
    if (ohmsSolveFor === "V") {
      const v = ohmsI * ohmsR;
      return {
        formula: "V = I × R",
        values: `I = ${ohmsI} A, R = ${ohmsR} Ω`,
        steps: [
          `V = I × R`,
          `V = ${ohmsI} A × ${ohmsR} Ω`,
          `V = ${v.toFixed(4)} V`
        ],
        result: v,
        unit: "V",
        report: `Ohm's Law Calculation:\n- Solved For: Voltage (V)\n- Current (I): ${ohmsI} A\n- Resistance (R): ${ohmsR} Ω\n- Formula: V = I × R\n- Step-by-step: V = ${ohmsI} × ${ohmsR} = ${v.toFixed(3)} V`
      };
    } else if (ohmsSolveFor === "I") {
      const i = ohmsR === 0 ? 0 : ohmsV / ohmsR;
      return {
        formula: "I = V / R",
        values: `V = ${ohmsV} V, R = ${ohmsR} Ω`,
        steps: [
          `I = V / R`,
          `I = ${ohmsV} V / ${ohmsR} Ω`,
          `I = ${i.toFixed(4)} A`
        ],
        result: i,
        unit: "A",
        report: `Ohm's Law Calculation:\n- Solved For: Current (I)\n- Voltage (V): ${ohmsV} V\n- Resistance (R): ${ohmsR} Ω\n- Formula: I = V / R\n- Step-by-step: I = ${ohmsV} / ${ohmsR} = ${i.toFixed(3)} A`
      };
    } else {
      const r = ohmsI === 0 ? 0 : ohmsV / ohmsI;
      return {
        formula: "R = V / I",
        values: `V = ${ohmsV} V, I = ${ohmsI} A`,
        steps: [
          `R = V / I`,
          `R = ${ohmsV} V / ${ohmsI} A`,
          `R = ${r.toFixed(4)} Ω`
        ],
        result: r,
        unit: "Ω",
        report: `Ohm's Law Calculation:\n- Solved For: Resistance (R)\n- Voltage (V): ${ohmsV} V\n- Current (I): ${ohmsI} A\n- Formula: R = V / I\n- Step-by-step: R = ${ohmsV} / ${ohmsI} = ${r.toFixed(3)} Ω`
      };
    }
  };

  // Voltage Divider
  const calculateDivider = () => {
    const rTotal = divR1 + divR2;
    const vOut = rTotal === 0 ? 0 : divVin * (divR2 / rTotal);
    return {
      vOut,
      rTotal,
      steps: [
        `RTOTAL = R1 + R2 = ${divR1} Ω + ${divR2} Ω = ${rTotal} Ω`,
        `VOUT = VIN × (R2 / RTOTAL)`,
        `VOUT = ${divVin} V × (${divR2} Ω / ${rTotal} Ω)`,
        `VOUT = ${divVin} V × ${(divR2 / rTotal).toFixed(4)}`,
        `VOUT = ${vOut.toFixed(4)} V`
      ],
      report: `Voltage Divider Calculation:\n- Input Voltage (Vin): ${divVin} V\n- Resistor R1: ${divR1} Ω\n- Resistor R2: ${divR2} Ω\n- Total Resistance (R_total): ${rTotal} Ω\n- Formula: Vout = Vin × [R2 / (R1 + R2)]\n- Calculation Steps:\n  1. R_total = ${divR1} + ${divR2} = ${rTotal} Ω\n  2. Vout = ${divVin} × (${divR2} / ${rTotal}) = ${vOut.toFixed(4)} V`
    };
  };

  // Beam Deflection
  const calculateBeam = () => {
    // E is in GPa (10^9 N/m²), I is in 10^-6 m^4.
    // Deflection delta = P * L^3 / (48 * E * I)
    // In Base SI Units:
    // P = beamLoad (N)
    // L = beamLength (m)
    // E_si = beamE * 1e9 (N/m²)
    // I_si = beamI * 1e-6 (m^4)
    // delta = P * L^3 / (48 * E_si * I_si)
    const E_si = beamE * 1e9;
    const I_si = beamI * 1e-6;
    const numerator = beamLoad * Math.pow(beamLength, 3);
    const denominator = 48 * E_si * I_si;
    const deflectionMeters = denominator === 0 ? 0 : numerator / denominator;
    const deflectionMm = deflectionMeters * 1000;

    return {
      deflectionMm,
      deflectionMeters,
      steps: [
        `P = ${beamLoad} N (Load)`,
        `L = ${beamLength} m (Length)`,
        `E = ${beamE} GPa = ${beamE} × 10⁹ Pa (Young's Modulus)`,
        `I = ${beamI} × 10⁻⁶ m⁴ (Area Moment of Inertia)`,
        `δmax = (P × L³) / (48 × E × I)`,
        `δmax = (${beamLoad} × ${beamLength}³) / (48 × [${beamE} × 10⁹] × [${beamI} × 10⁻⁶])`,
        `δmax = (${numerator.toFixed(1)}) / (${denominator.toFixed(1)})`,
        `δmax = ${deflectionMeters.toExponential(4)} m`,
        `δmax = ${deflectionMm.toFixed(3)} mm`
      ],
      report: `Simply Supported Beam Deflection Analysis:\n- Concentrated Center Load (P): ${beamLoad} N\n- Beam Span (L): ${beamLength} m\n- Modulus of Elasticity (E): ${beamE} GPa\n- Moment of Inertia (I): ${beamI} × 10^-6 m^4\n- Formula: δ_max = (P · L³) / (48 · E · I)\n- Core Math:\n  - Numerator: P·L³ = ${beamLoad} · ${Math.pow(beamLength, 3)} = ${numerator.toFixed(1)}\n  - Denominator: 48·E·I = 48 · ${beamE}e9 · ${beamI}e-6 = ${denominator.toFixed(1)}\n  - Peak Deflection (δ): ${deflectionMm.toFixed(3)} mm`
    };
  };

  // Vibration
  const calculateVibration = () => {
    // Natural Frequency: w_n = sqrt(k/m)
    // Frequency in Hz: f_n = w_n / (2*pi)
    // Critical Damping: C_c = 2 * sqrt(m * k)
    // Damping Ratio: zeta = C / C_c
    const wn = vibM <= 0 ? 0 : Math.sqrt(vibK / vibM);
    const fn = wn / (2 * Math.PI);
    const Cc = 2 * Math.sqrt(vibM * vibK);
    const zeta = Cc === 0 ? 0 : vibC / Cc;

    let dampingRegime = "Undamped";
    if (zeta === 0) dampingRegime = "Undamped";
    else if (zeta < 1) dampingRegime = "Underdamped (oscillates with decaying amplitude)";
    else if (zeta === 1) dampingRegime = "Critically Damped (fastest return to equilibrium without overshoot)";
    else dampingRegime = "Overdamped (sluggish decay to equilibrium without oscillation)";

    return {
      wn,
      fn,
      Cc,
      zeta,
      dampingRegime,
      steps: [
        `ωn = √(k / m) = √(${vibK} / ${vibM}) = ${wn.toFixed(3)} rad/s`,
        `fn = ωn / (2π) = ${wn.toFixed(3)} / (2 × 3.14159) = ${fn.toFixed(3)} Hz`,
        `Cc = 2 × √(m × k) = 2 × √(${vibM} × ${vibK}) = ${Cc.toFixed(1)} N·s/m (Critical Damping)`,
        `ζ = c / Cc = ${vibC} / ${Cc.toFixed(1)} = ${zeta.toFixed(4)} (Damping Ratio)`,
        `System Regime: ${dampingRegime}`
      ],
      report: `Spring-Mass-Damper Dynamic Transient Analysis:\n- Mass (m): ${vibM} kg\n- Stiffness (k): ${vibK} N/m\n- Damping Coefficient (c): ${vibC} N·s/m\n- System Performance Metrics:\n  1. Natural Frequency (ωn): ${wn.toFixed(3)} rad/s (${fn.toFixed(3)} Hz)\n  2. Critical Damping (Cc): ${Cc.toFixed(1)} N·s/m\n  3. Damping Ratio (ζ): ${zeta.toFixed(4)}\n- Vibrational Classification: ${dampingRegime}`
    };
  };

  // Reynolds Number
  const calculateReynolds = () => {
    // Re = rho * v * D / mu
    const Re = reyMu === 0 ? 0 : (reyRho * reyV * reyD) / reyMu;
    let flowState = "Laminar Flow";
    if (Re < 2300) {
      flowState = "Laminar Flow (viscous forces dominate; smooth, aligned streamline motion)";
    } else if (Re >= 2300 && Re <= 4000) {
      flowState = "Transitional Flow (intermittent fluctuations; unstable boundary layer)";
    } else {
      flowState = "Turbulent Flow (inertial forces dominate; chaotic fluid eddies and random mixing)";
    }

    return {
      Re,
      flowState,
      steps: [
        `Re = (ρ × V × D) / μ`,
        `Re = (${reyRho} kg/m³ × ${reyV} m/s × ${reyD} m) / ${reyMu} Pa·s`,
        `Re = ${(reyRho * reyV * reyD).toFixed(2)} / ${reyMu}`,
        `Re = ${Re.toLocaleString(undefined, { maximumFractionDigits: 1 })}`,
        `Flow Dynamic State: ${flowState}`
      ],
      report: `Fluid Hydrodynamic Reynolds Number Solver:\n- Fluid Density (ρ): ${reyRho} kg/m³\n- Mean Velocity (V): ${reyV} m/s\n- Pipe Inner Diameter (D): ${reyD} m\n- Dynamic Viscosity (μ): ${reyMu} Pa·s\n- Formula: Re = (ρ · V · D) / μ\n- Computed Reynolds Number (Re): ${Re.toLocaleString(undefined, { maximumFractionDigits: 1 })}\n- Flow Classification: ${flowState}`
    };
  };

  // Carnot Efficiency
  const calculateCarnot = () => {
    // eff = 1 - Tc/Th
    // Validate Temps (Kelvin must be > 0 and Th > Tc)
    const isValid = carTh > 0 && carTh > carTc;
    const efficiency = isValid ? 1 - carTc / carTh : 0;
    const effPercent = efficiency * 100;

    return {
      efficiency,
      effPercent,
      isValid,
      steps: [
        `Th = ${carTh} K (Hot Source Temperature)`,
        `Tc = ${carTc} K (Cold Sink Temperature)`,
        `ηmax = 1 - (Tc / Th)`,
        isValid
          ? `ηmax = 1 - (${carTc} / ${carTh})`
          : "Invalid inputs: Hot temperature must be strictly greater than cold temperature (Newton's 2nd law constraint).",
        isValid ? `ηmax = 1 - ${(carTc / carTh).toFixed(4)} = ${efficiency.toFixed(4)}` : "-",
        isValid ? `Thermal Power Efficiency: ${effPercent.toFixed(2)}%` : "-"
      ],
      report: `Thermodynamic Carnot Cycle Maximum Efficiency Analysis:\n- Hot Reservoir Temp (Th): ${carTh} K\n- Cold Sink Temp (Tc): ${carTc} K\n- Ideal Efficiency Limit (η): ${effPercent.toFixed(2)}%\n- Formula: η = 1 - (Tc / Th)\n- Structural Heat Equation Steps:\n  1. Tc/Th Ratio = ${carTc} / ${carTh} = ${(carTc / carTh).toFixed(4)}\n  2. Max Efficiency = 1 - ${(carTc / carTh).toFixed(4)} = ${efficiency.toFixed(4)} (${effPercent.toFixed(2)}%)`
    };
  };

  const ohmsData = calculateOhms();
  const divData = calculateDivider();
  const beamData = calculateBeam();
  const vibData = calculateVibration();
  const reyData = calculateReynolds();
  const carnotData = calculateCarnot();

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-full shadow-2xl">
      {/* Tab bar header */}
      <div className="bg-slate-950 border-b border-slate-800 p-2 flex flex-wrap gap-1 items-center justify-between">
        <div className="flex flex-wrap gap-1">
          <button
            id="tab-ohms"
            onClick={() => setActiveTab("ohms")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeTab === "ohms"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Zap className="w-3.5 h-3.5 inline mr-1.5" />
            Ohm's Law
          </button>
          <button
            id="tab-divider"
            onClick={() => setActiveTab("divider")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeTab === "divider"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Zap className="w-3.5 h-3.5 inline mr-1.5" />
            Voltage Divider
          </button>
          <button
            id="tab-beam"
            onClick={() => setActiveTab("beam")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeTab === "beam"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Layers className="w-3.5 h-3.5 inline mr-1.5" />
            Beam Bending
          </button>
          <button
            id="tab-vibration"
            onClick={() => setActiveTab("vibration")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeTab === "vibration"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Activity className="w-3.5 h-3.5 inline mr-1.5" />
            Vibrations
          </button>
          <button
            id="tab-reynolds"
            onClick={() => setActiveTab("reynolds")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeTab === "reynolds"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5 inline mr-1.5" />
            Reynolds Flow
          </button>
          <button
            id="tab-carnot"
            onClick={() => setActiveTab("carnot")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
              activeTab === "carnot"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Layers className="w-3.5 h-3.5 inline mr-1.5" />
            Thermodynamics
          </button>
        </div>
      </div>

      {/* Main body of the calc workspace */}
      <div className="flex-1 p-5 overflow-y-auto grid grid-cols-1 lg:grid-cols-2 gap-6 select-none">
        {/* Left column: Controls */}
        <div className="space-y-5">
          <div>
            <h3 className="text-slate-100 font-bold text-base tracking-tight mb-1">
              {activeTab === "ohms" && "Ohm's Law Solver"}
              {activeTab === "divider" && "Voltage Divider Workstation"}
              {activeTab === "beam" && "Simply Supported Beam Deflection"}
              {activeTab === "vibration" && "Mass-Spring-Damper Oscillation Lab"}
              {activeTab === "reynolds" && "Reynolds Number Fluid Classifier"}
              {activeTab === "carnot" && "Carnot Efficiency Heat Engine"}
            </h3>
            <p className="text-slate-400 text-xs font-normal">
              {activeTab === "ohms" && "Calculate electrical networks linking Voltage, Current, and Load Resistance."}
              {activeTab === "divider" && "Design passive circuit drop dividing networks by configuring dual resistances."}
              {activeTab === "beam" && "Perform mechanical structural deflection calculations for safety limit checks."}
              {activeTab === "vibration" && "Analyze harmonic motion systems, damping factors, and system decay."}
              {activeTab === "reynolds" && "Classify internal pipe flows as laminar, transitional, or turbulent states."}
              {activeTab === "carnot" && "Analyze the absolute physical limit of thermal work using thermodynamic systems."}
            </p>
          </div>

          {/* Dynamic input render depending on Active Tab */}
          <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800 space-y-4">
            {activeTab === "ohms" && (
              <div className="space-y-4">
                <div className="flex gap-2 p-1 bg-slate-900 rounded-lg border border-slate-800">
                  {(["V", "I", "R"] as const).map((variable) => (
                    <button
                      key={variable}
                      onClick={() => setOhmsSolveFor(variable)}
                      className={`flex-1 py-1 rounded text-xs font-semibold cursor-pointer ${
                        ohmsSolveFor === variable
                          ? "bg-slate-700 text-amber-400"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      Solve for {variable === "V" ? "Voltage (V)" : variable === "I" ? "Current (I)" : "Resistance (R)"}
                    </button>
                  ))}
                </div>

                {ohmsSolveFor !== "V" && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono text-slate-400">
                      <span>Voltage (V): {ohmsV} V</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="240"
                      value={ohmsV}
                      onChange={(e) => setOhmsV(Number(e.target.value))}
                      className="w-full accent-amber-500 h-1 roundedbg-slate-800"
                    />
                  </div>
                )}

                {ohmsSolveFor !== "I" && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono text-slate-400">
                      <span>Current (I): {ohmsI} A</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="20"
                      step="0.1"
                      value={ohmsI}
                      onChange={(e) => setOhmsI(Number(e.target.value))}
                      className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                    />
                  </div>
                )}

                {ohmsSolveFor !== "R" && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono text-slate-400">
                      <span>Resistance (R): {ohmsR} Ω</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="1000"
                      value={ohmsR}
                      onChange={(e) => setOhmsR(Number(e.target.value))}
                      className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                    />
                  </div>
                )}
              </div>
            )}

            {activeTab === "divider" && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Input Voltage (Vin): {divVin} V</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="100"
                    value={divVin}
                    onChange={(e) => setDivVin(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Resistor R1: {divR1} Ω</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="10000"
                    step="10"
                    value={divR1}
                    onChange={(e) => setDivR1(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Resistor R2: {divR2} Ω</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="10000"
                    step="10"
                    value={divR2}
                    onChange={(e) => setDivR2(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>
              </div>
            )}

            {activeTab === "beam" && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Center Point Load (P): {beamLoad.toLocaleString()} N</span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="50000"
                    step="100"
                    value={beamLoad}
                    onChange={(e) => setBeamLoad(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Beam Length Span (L): {beamLength} m</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="0.5"
                    value={beamLength}
                    onChange={(e) => setBeamLength(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Young's Modulus (E): {beamE} GPa</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="400"
                    value={beamE}
                    onChange={(e) => setBeamE(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Concrete ≈ 30</span>
                    <span>Alu ≈ 69</span>
                    <span>Steel ≈ 200</span>
                    <span>Titanium ≈ 114</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Moment of Inertia (I): {beamI} × 10⁻⁶ m⁴</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="1000"
                    value={beamI}
                    onChange={(e) => setBeamI(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>
              </div>
            )}

            {activeTab === "vibration" && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Oscillating Mass (m): {vibM} kg</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="200"
                    value={vibM}
                    onChange={(e) => setVibM(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Spring Constant (k): {vibK} N/m</span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="10000"
                    step="100"
                    value={vibK}
                    onChange={(e) => setVibK(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Damping Variable (c): {vibC} N·s/m</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="500"
                    step="5"
                    value={vibC}
                    onChange={(e) => setVibC(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>c = 0 (No damping)</span>
                    <span>c &lt; Cc (Underdamped oscillations)</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "reynolds" && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Fluid flow Velocity (V): {reyV} m/s</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="10"
                    step="0.1"
                    value={reyV}
                    onChange={(e) => setReyV(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Pipe Diameter (D): {reyD} m ({Math.round(reyD * 1000)} mm)</span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="0.5"
                    step="0.01"
                    value={reyD}
                    onChange={(e) => setReyD(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Fluid Density (ρ): {reyRho} kg/m³</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="2000"
                    step="10"
                    value={reyRho}
                    onChange={(e) => setReyRho(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Air ≈ 1.2 kg/m³</span>
                    <span>Hydraulic Oil ≈ 880 kg/m³</span>
                    <span>Water ≈ 1000 kg/m³</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Viscosity (μ): {reyMu.toFixed(5)} Pa·s</span>
                  </div>
                  <input
                    type="range"
                    min="0.0001"
                    max="0.05"
                    step="0.0001"
                    value={reyMu}
                    onChange={(e) => setReyMu(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Air ≈ 1.8e-5</span>
                    <span>Water ≈ 0.001</span>
                    <span>Engine Oil ≈ 0.03</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "carnot" && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Hot Source Temp (Th): {carTh} K ({Math.round(carTh - 273.15)} °C)</span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="2000"
                    step="10"
                    value={carTh}
                    onChange={(e) => setCarTh(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Cold Sink Temp (Tc): {carTc} K ({Math.round(carTc - 273.15)} °C)</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="1000"
                    step="5"
                    value={carTc}
                    onChange={(e) => setCarTc(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 rounded bg-slate-800"
                  />
                </div>

                {carTc >= carTh && (
                  <div className="text-[11px] font-medium text-red-400 bg-red-950/40 p-2 rounded-lg border border-red-900/40">
                    Physical Violation: Cold sink cannot equal or exceed Hot source temperature (2nd Law Thermodynamics).
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Footer */}
          <button
            onClick={() => {
              let reportText = "";
              if (activeTab === "ohms") reportText = ohmsData.report;
              else if (activeTab === "divider") reportText = divData.report;
              else if (activeTab === "beam") reportText = beamData.report;
              else if (activeTab === "vibration") reportText = vibData.report;
              else if (activeTab === "reynolds") reportText = reyData.report;
              else if (activeTab === "carnot") reportText = carnotData.report;

              onExportToChat(reportText);
              showCopyMessage("export");
            }}
            className="w-full flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2.5 px-4 rounded-xl shadow-lg shadow-amber-500/10 cursor-pointer transition-all hover:scale-[1.01] text-xs"
          >
            <Copy className="w-4 h-4" />
            {copiedStatus === "export" ? "Calculations Exported!" : "Export System Report to Engiquery Chat"}
          </button>
        </div>

        {/* Right column: Animation & Solutions */}
        <div className="space-y-5 flex flex-col justify-between">
          {/* Dynamic SVG Schematic Box */}
          <div className="bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex flex-col h-48 justify-center items-center relative">
            <span className="absolute top-2 left-2 text-[9px] font-mono tracking-widest text-slate-500 flex items-center gap-1 uppercase select-none">
              <Activity className="w-3 h-3 text-amber-500" /> Dynamic Physics Schematic
            </span>

            {/* OHMS LAW SCHEMA */}
            {activeTab === "ohms" && (
              <svg className="w-4/5 h-2/3" viewBox="0 0 400 150">
                {/* Circuit wire */}
                <rect x="50" y="30" width="300" height="90" fill="none" stroke="#334155" strokeWidth="2.5" />
                {/* Voltage source */}
                <circle cx="50" cy="75" r="16" fill="#0f172a" stroke="#f59e0b" strokeWidth="3" />
                <text x="50" y="79" fill="#f59e0b" fontSize="13" fontWeight="bold" textAnchor="middle">
                  V
                </text>
                {/* Current Arrow */}
                <path d="M 120 22 L 180 22" fill="none" stroke="#22c55e" strokeWidth="2" strokeDasharray="3" />
                <path d="M 180 22 L 183 22 L 177 19 M 180 22 L 177 25" fill="none" stroke="#22c55e" strokeWidth="2" />
                <text x="150" y="15" fill="#22c55e" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  I = {ohmsSolveFor === "I" ? ohmsData.result.toFixed(2) : ohmsI}A
                </text>
                {/* Resistor zig-zag */}
                <path
                  d="M 350 30 L 350 55 L 340 60 L 360 65 L 340 70 L 360 75 L 340 80 L 360 85 L 350 90 L 350 120"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="3"
                />
                <text x="315" y="79" fill="#38bdf8" fontSize="10" fontFamily="monospace" textAnchor="end">
                  R = {ohmsSolveFor === "R" ? ohmsData.result.toFixed(1) : ohmsR}Ω
                </text>
                {/* Outgoing values */}
                <text x="200" y="138" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">
                  Source: {ohmsSolveFor === "V" ? ohmsData.result.toFixed(1) : ohmsV}V
                </text>
              </svg>
            )}

            {/* VOLTAGE DIVIDER SCHEMA */}
            {activeTab === "divider" && (
              <svg className="w-4/5 h-2/3" viewBox="0 0 400 150">
                {/* Main Ground and In Rails */}
                <path d="M 50 30 L 150 30" fill="none" stroke="#475569" strokeWidth="2" />
                <path d="M 50 120 L 250 120" fill="none" stroke="#475569" strokeWidth="2" />
                {/* R1 zig-zag */}
                <path d="M 150 30 L 150 50 L 142 53 L 158 57 L 142 61 L 158 65 L 142 69 L 158 73 L 150 76 L 150 82" fill="none" stroke="#f59e0b" strokeWidth="2.5" />
                <text x="110" y="62" fill="#f59e0b" fontSize="9" fontFamily="monospace">R1={divR1}Ω</text>
                {/* Node center */}
                <circle cx="150" cy="82" r="3" fill="#38bdf8" />
                {/* R2 zig-zag */}
                <path d="M 150 82 L 150 90 L 142 93 L 158 97 L 142 101 L 158 105 L 142 109 L 158 113 L 150 116 L 150 120" fill="none" stroke="#f59e0b" strokeWidth="2.5" />
                <text x="110" y="106" fill="#f59e0b" fontSize="9" fontFamily="monospace">R2={divR2}Ω</text>
                {/* Vout Line */}
                <path d="M 150 82 L 280 82" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="2" />
                <circle cx="280" cy="82" r="4" fill="#38bdf8" />
                <text x="290" y="86" fill="#38bdf8" fontSize="10" fontFamily="monospace" fontWeight="bold">Vout={divData.vOut.toFixed(2)}V</text>
                {/* Ground marker */}
                <path d="M 250 120 L 250 130 M 244 130 L 256 130 M 247 134 L 253 134 M 249 138 L 251 138" fill="none" stroke="#475569" strokeWidth="1.5" />
                <text x="20" y="34" fill="#94a3b8" fontSize="10" fontFamily="monospace">Vin = {divVin}V</text>
              </svg>
            )}

            {/* BEAM LOAD SCHEMA */}
            {activeTab === "beam" && (
              <svg className="w-4/5 h-2/3" viewBox="0 0 400 150">
                {/* Ground lines */}
                <line x1="40" y1="110" x2="360" y2="110" stroke="#334155" strokeWidth="1.5" strokeDasharray="3" />
                {/* Supports */}
                <polygon points="60,110 50,95 70,95" fill="#f59e0b" />
                <polygon points="340,110 330,95 350,95" fill="#f59e0b" />
                {/* Beam */}
                <path
                  d={`M 60 92 Q 200 ${92 + Math.min(beamData.deflectionMm * 2.5, 45)} 340 92`}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="6"
                  strokeLinecap="round"
                />
                {/* Load Arrow */}
                <path d="M 200 20 L 200 70" fill="none" stroke="#ef4444" strokeWidth="3" />
                <path d="M 194 62 L 200 70 L 206 62" fill="none" stroke="#ef4444" strokeWidth="3" />
                <text x="200" y="15" fill="#ef4444" fontSize="10" fontWeight="bold" textAnchor="middle">
                  Load (P): {beamLoad}N
                </text>
                {/* Dimension label */}
                <text x="200" y="135" fill="#94a3b8" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  Beam Span (L) = {beamLength}m | Deflection (δ) ≈ {beamData.deflectionMm.toFixed(2)} mm
                </text>
              </svg>
            )}

            {/* VIBRATION SYSTEM */}
            {activeTab === "vibration" && (
              <svg className="w-4/5 h-2/3" viewBox="0 0 400 150">
                {/* Ceiling */}
                <rect x="50" y="20" width="300" height="6" fill="#334155" />
                {/* Spring zig zag */}
                <path d="M 120 26 L 120 40 L 110 46 L 130 54 L 110 62 L 130 70 L 110 78 L 130 86 L 120 92 L 120 100" fill="none" stroke="#f59e0b" strokeWidth="2.5" />
                <text x="85" y="60" fill="#f59e0b" fontSize="9" fontFamily="monospace">Stiffness k</text>
                {/* Damper cylinder */}
                <path d="M 240 26 L 240 50 M 225 50 L 255 50 M 225 70 L 255 70 L 255 50 M 240 70 L 240 100" fill="none" stroke="#38bdf8" strokeWidth="2" />
                <text x="270" y="60" fill="#38bdf8" fontSize="9" fontFamily="monospace">Damping c</text>
                {/* Mass Block */}
                <rect x="80" y="100" width="200" height="28" rx="4" fill="#0f172a" stroke="#22c55e" strokeWidth="3" />
                <text x="180" y="117" fill="#22c55e" fontSize="10" fontWeight="bold" textAnchor="middle">
                  Mass (m) = {vibM} kg
                </text>
                {/* Analysis readout */}
                <text x="180" y="142" fill="#94a3b8" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  Ratio ζ = {vibData.zeta.toFixed(3)} | Regime: {vibData.dampingRegime.split(" ")[0]}
                </text>
              </svg>
            )}

            {/* FLUID FLOW CYLINDER */}
            {activeTab === "reynolds" && (
              <svg className="w-4/5 h-2/3" viewBox="0 0 400 150">
                {/* Pipe boundaries */}
                <rect x="40" y="30" width="320" height="75" fill="#020617" stroke="#475569" strokeWidth="3" />
                {/* Streamlines */}
                {reyData.Re < 2300 ? (
                  // Laminar Flow - Straight lines
                  <g stroke="#38bdf8" strokeWidth="1.5" opacity="0.8">
                    <line x1="50" y1="45" x2="350" y2="45" />
                    <line x1="50" y1="58" x2="350" y2="58" />
                    <line x1="50" y1="72" x2="350" y2="72" />
                    <line x1="50" y1="85" x2="350" y2="85" />
                    <line x1="50" y1="95" x2="350" y2="95" />
                  </g>
                ) : reyData.Re >= 2300 && reyData.Re <= 4000 ? (
                  // Transitional Flow - Slightly wavy
                  <g stroke="#fb923c" strokeWidth="1.5" fill="none" opacity="0.8">
                    <path d="M 50 45 Q 120 40 200 50 T 350 45" />
                    <path d="M 50 58 Q 130 65 210 52 T 350 58" />
                    <path d="M 50 72 Q 110 65 190 78 T 350 72" />
                    <path d="M 50 85 Q 140 92 220 80 T 350 85" />
                  </g>
                ) : (
                  // Turbulent Flow - Chaotic eddies
                  <g stroke="#f87171" strokeWidth="1.5" fill="none" opacity="0.7">
                    <path d="M 50 45 Q 80 70 110 40 T 170 50 T 230 40 T 290 60 T 350 45" />
                    <path d="M 50 65 Q 90 40 130 75 T 190 55 T 250 80 T 310 50 T 350 65" />
                    <path d="M 50 85 Q 75 99 100 80 T 160 90 T 220 70 T 280 90 T 350 85" />
                    <span />
                  </g>
                )}
                {/* Arrow Vector */}
                <line x1="10" y1="67" x2="35" y2="67" stroke="#22c55e" strokeWidth="2" />
                <polygon points="35,67 28,63 28,71" fill="#22c55e" />
                {/* Re Readout */}
                <text x="200" y="128" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">
                  Re Ratio = {Math.round(reyData.Re).toLocaleString()} ({reyData.flowState.split(" ")[0]})
                </text>
              </svg>
            )}

            {/* CARNOT HEAT ENGINE */}
            {activeTab === "carnot" && (
              <svg className="w-4/5 h-2/3" viewBox="0 0 400 150">
                {/* Source Boiler */}
                <rect x="40" y="35" width="80" height="45" rx="4" fill="#991b1b" stroke="#f87171" strokeWidth="2" />
                <text x="80" y="55" fill="#fecaca" fontSize="9" fontWeight="bold" textAnchor="middle">Hot Source</text>
                <text x="80" y="70" fill="#f87171" fontSize="9" fontFamily="monospace" textAnchor="middle">Th={carTh}K</text>
                {/* Work Out */}
                <path d="M 120 57 L 280 57" fill="none" stroke="#eab308" strokeWidth="3" />
                <polygon points="280,57 272,52 272,62" fill="#eab308" />
                <text x="200" y="47" fill="#eab308" fontSize="10" fontWeight="bold" textAnchor="middle">WORK OUTPUT</text>
                {/* Sink Condenser */}
                <rect x="280" y="35" width="80" height="45" rx="4" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="2" />
                <text x="320" y="55" fill="#dbeafe" fontSize="9" fontWeight="bold" textAnchor="middle">Cold Sink</text>
                <text x="320" y="70" fill="#60a5fa" fontSize="9" fontFamily="monospace" textAnchor="middle">Tc={carTc}K</text>
                {/* Text Indicator */}
                <text x="200" y="115" fill="#22c55e" fontSize="11" fontWeight="bold" textAnchor="middle">
                  Ideal Eff (η) = {carnotData.effPercent.toFixed(2)}%
                </text>
                <text x="200" y="135" fill="#94a3b8" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  Maximum possible efficiency limited by the 2nd Law
                </text>
              </svg>
            )}
          </div>

          {/* Mathematical formulation block */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-5 flex-1 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-[10px] font-mono tracking-widest text-[#f59e0b] uppercase font-bold">
                Analytical Steps Output
              </span>

              {/* Equation printout depending on tab */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono text-[11px] text-slate-300 space-y-1.5 overflow-x-auto max-h-56">
                {activeTab === "ohms" && ohmsData.steps.map((st, i) => <div key={i} className={i === ohmsData.steps.length - 1 ? "text-amber-400 font-bold mt-1" : ""}>{st}</div>)}
                {activeTab === "divider" && divData.steps.map((st, i) => <div key={i} className={i === divData.steps.length - 1 ? "text-amber-400 font-bold mt-1" : ""}>{st}</div>)}
                {activeTab === "beam" && beamData.steps.map((st, i) => <div key={i} className={i === beamData.steps.length - 1 ? "text-amber-400 font-bold mt-1" : ""}>{st}</div>)}
                {activeTab === "vibration" && vibData.steps.map((st, i) => <div key={i} className={i === vibData.steps.length - 1 ? "text-amber-400 font-bold mt-1" : ""}>{st}</div>)}
                {activeTab === "reynolds" && reyData.steps.map((st, i) => <div key={i} className={i === reyData.steps.length - 1 ? "text-amber-400 font-bold mt-1" : ""}>{st}</div>)}
                {activeTab === "carnot" && carnotData.steps.map((st, i) => <div key={i} className={i === carnotData.steps.length - 1 ? "text-amber-400 font-bold mt-1" : ""}>{st}</div>)}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 mt-4 flex justify-between items-center">
              <div className="text-xs text-slate-400">
                Current State Unit:{" "}
                <span className="font-mono text-slate-100 font-semibold">
                  {activeTab === "ohms" && ohmsData.unit}
                  {activeTab === "divider" && "Volts (V)"}
                  {activeTab === "beam" && "Millimeters (mm)"}
                  {activeTab === "vibration" && "Rotational (rad/s)"}
                  {activeTab === "reynolds" && "Dimensionless (Re)"}
                  {activeTab === "carnot" && "Theoretical Fraction"}
                </span>
              </div>
              <div className="text-right">
                <div className="text-[10px] text-slate-500 uppercase select-none font-mono">Solved Output</div>
                <div className="text-lg font-bold text-amber-400 font-mono">
                  {activeTab === "ohms" && (ohmsSolveFor === "V" ? `${ohmsData.result.toFixed(2)} V` : ohmsSolveFor === "I" ? `${ohmsData.result.toFixed(3)} A` : `${ohmsData.result.toFixed(1)} Ω`)}
                  {activeTab === "divider" && `${divData.vOut.toFixed(3)} V`}
                  {activeTab === "beam" && `${beamData.deflectionMm.toFixed(3)} mm`}
                  {activeTab === "vibration" && `Ratio ζ = ${vibData.zeta.toFixed(3)}`}
                  {activeTab === "reynolds" && `${Math.round(reyData.Re).toLocaleString()}`}
                  {activeTab === "carnot" && `${carnotData.effPercent.toFixed(1)}%`}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
