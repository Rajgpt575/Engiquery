import React, { useState } from "react";
import { Search, Database, Scale, Copy, BookOpen, ClipboardCheck } from "lucide-react";
import { ENGINEERING_CONSTANTS, MATERIAL_DATABASE, CONVERSION_CATEGORIES, MaterialProperty } from "../data";
import { ScienceConstant } from "../types";

interface ReferenceDeskProps {
  onExportToChat: (text: string) => void;
}

export default function ReferenceDesk({ onExportToChat }: ReferenceDeskProps) {
  const [activeSubTab, setActiveSubTab] = useState<"constants" | "materials" | "conventions">("constants");

  // Filter Constants search
  const [constSearch, setConstSearch] = useState("");
  const [constCategory, setConstCategory] = useState<string>("All");

  // Materials active selection
  const [selectedMaterial, setSelectedMaterial] = useState<MaterialProperty>(MATERIAL_DATABASE[0]);

  // Conversions active variables
  const [convCategoryIndex, setConvCategoryIndex] = useState(0);
  const [convVal, setConvVal] = useState<number>(1);
  const [convFromIndex, setConvFromIndex] = useState(0);
  const [convToIndex, setConvToIndex] = useState(1);

  // Clipboard copies
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopyClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleExportItem = (title: string, text: string) => {
    onExportToChat(`Engineering Reference Study: [${title}]\n\n${text}`);
    setCopiedKey(`export-${title}`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Convert execution
  const currentConvCategory = CONVERSION_CATEGORIES[convCategoryIndex];
  const fromUnit = currentConvCategory.units[convFromIndex] || currentConvCategory.units[0];
  const toUnit = currentConvCategory.units[convToIndex] || currentConvCategory.units[1];

  const calculateConversion = () => {
    if (!fromUnit || !toUnit) return { result: 0, scale: "" };
    // Conversion formula: Value * (toUnit.factor / fromUnit.factor)
    // Because factors are defined relative to baseline 1.
    // E.g. meter has factor 1, ft has factor 3.28084.
    // 5 meters to feet: 5 * (3.28084 / 1) = 16.4042 feet.
    // 10 feet to meters: 10 * (1 / 3.28084) = 3.048 meters.
    const result = convVal * (toUnit.factor / fromUnit.factor);
    const scale = `${convVal} ${fromUnit.symbol} = ${result.toLocaleString(undefined, { maximumFractionDigits: 5 })} ${toUnit.symbol}`;
    return { result, scale };
  };

  const convResult = calculateConversion();

  // Filter Constants list
  const filteredConstants = ENGINEERING_CONSTANTS.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(constSearch.toLowerCase()) ||
      c.symbol.toLowerCase().includes(constSearch.toLowerCase());
    const matchesCategory = constCategory === "All" || c.category === constCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-full shadow-2xl">
      {/* Sub tabs */}
      <div className="bg-slate-950 border-b border-slate-800 p-2 flex gap-1 items-center justify-between">
        <div className="flex gap-1">
          <button
            id="ref-tab-constants"
            onClick={() => setActiveSubTab("constants")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeSubTab === "constants"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 inline mr-1.5" />
            Physical Constants
          </button>
          <button
            id="ref-tab-materials"
            onClick={() => setActiveSubTab("materials")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeSubTab === "materials"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Database className="w-3.5 h-3.5 inline mr-1.5" />
            Materials Directory
          </button>
          <button
            id="ref-tab-conventions"
            onClick={() => setActiveSubTab("conventions")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeSubTab === "conventions"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            }`}
          >
            <Scale className="w-3.5 h-3.5 inline mr-1.5" />
            Unit Workbench
          </button>
        </div>
      </div>

      <div className="flex-1 p-5 overflow-y-auto select-none">
        {/* PHYSICAL CONSTANTS VIEW */}
        {activeSubTab === "constants" && (
          <div className="space-y-4 h-full flex flex-col">
            <div className="flex flex-col sm:flex-row gap-2 justify-between">
              {/* Search bar */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search constants (e.g. Speed of Light, gravity...)"
                  value={constSearch}
                  onChange={(e) => setConstSearch(e.target.value)}
                  className="w-full bg-slate-950/60 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-xs text-slate-100 focus:outline-none focus:border-amber-500 h-9 font-sans"
                />
              </div>

              {/* Constants select filter */}
              <div className="flex gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto h-9 items-center">
                {(["All", "Physics", "Chemistry", "Mathematics"] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setConstCategory(cat)}
                    className={`px-3 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-all ${
                      constCategory === cat
                        ? "bg-slate-800 text-amber-400"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Constants table mapping */}
            <div className="border border-slate-800 bg-slate-950/40 rounded-xl overflow-hidden flex-1 overflow-y-auto max-h-[340px]">
              <table className="w-full border-collapse text-left text-xs text-slate-300">
                <thead>
                  <tr className="bg-slate-950 border-b border-slate-800 font-mono text-[9px] text-slate-500 tracking-wider">
                    <th className="p-3 pl-4">Constant</th>
                    <th className="p-3">Symbol</th>
                    <th className="p-3 font-mono">Value</th>
                    <th className="p-3">Units</th>
                    <th className="p-3 text-right pr-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredConstants.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-500">
                        No sci-constants match the active filters.
                      </td>
                    </tr>
                  ) : (
                    filteredConstants.map((c) => {
                      const clipboardValue = `${c.name} (${c.symbol}) = ${c.value} ${c.unit}`;
                      const reportValue = `Constant: ${c.name}\n- Symbol: ${c.symbol}\n- Value: ${c.value}\n- Unit: ${c.unit}\n- Classification: ${c.category}\n- Description: ${c.description}`;

                      return (
                        <tr key={c.name} className="hover:bg-slate-900 group transition-all">
                          <td className="p-3 pl-4">
                            <div className="font-semibold text-slate-100">{c.name}</div>
                            <div className="text-[10px] text-slate-500 truncate max-w-xs">{c.description}</div>
                          </td>
                          <td className="p-3 font-mono text-amber-400 font-bold text-sm select-all">{c.symbol}</td>
                          <td className="p-3 font-mono text-emerald-400 select-all">{c.value}</td>
                          <td className="p-3 font-mono text-slate-400">{c.unit}</td>
                          <td className="p-3 text-right pr-4 space-x-1.5 opacity-80 group-hover:opacity-100">
                            <button
                              onClick={() => handleCopyClipboard(clipboardValue, c.name)}
                              title="Copy to Clipboard"
                              className="p-1 px-1.5 rounded bg-slate-800 border border-slate-700 hover:border-amber-500 hover:bg-slate-700 text-slate-300 hover:text-amber-400 cursor-pointer text-[10px]"
                            >
                              {copiedKey === c.name ? <ClipboardCheck className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                            <button
                              onClick={() => handleExportItem(c.name, reportValue)}
                              title="Export to Chat"
                              className="p-1 px-2 rounded bg-slate-800 border border-slate-700 hover:border-amber-500 hover:bg-slate-700 text-xs font-semibold text-amber-500 cursor-pointer text-[10px]"
                            >
                              {copiedKey === `export-${c.name}` ? "Exported" : "Chat"}
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* MATERIALS DIRECTORY VIEW */}
        {activeSubTab === "materials" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 h-full">
            {/* List column */}
            <div className="md:col-span-1 border border-slate-800 rounded-xl overflow-hidden bg-slate-950/25 flex flex-col max-h-[380px] overflow-y-auto">
              <div className="p-3 bg-slate-950 border-b border-slate-800 text-[10px] font-mono tracking-wider uppercase text-slate-500">
                Material Assets
              </div>
              <div className="divide-y divide-slate-800">
                {MATERIAL_DATABASE.map((mat) => (
                  <button
                    key={mat.name}
                    onClick={() => setSelectedMaterial(mat)}
                    className={`w-full p-3 text-left font-medium text-xs block cursor-pointer transition-all ${
                      selectedMaterial.name === mat.name
                        ? "bg-slate-800/80 text-amber-400 border-l-4 border-amber-500"
                        : "text-slate-400 hover:text-slate-100 hover:bg-slate-900/50"
                    }`}
                  >
                    {mat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Details panel */}
            <div className="md:col-span-2 bg-slate-950/40 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-slate-100">{selectedMaterial.name}</h4>
                  <p className="text-slate-400 text-[11px] font-normal mt-1 leading-relaxed">{selectedMaterial.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-3.5 pt-2">
                  <div className="bg-slate-900/70 border border-slate-800/60 p-3 rounded-xl">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Young's Modulus (E)</div>
                    <div className="text-sm font-bold font-mono text-slate-100 mt-1">{selectedMaterial.youngsModulus} GPa</div>
                  </div>
                  <div className="bg-slate-900/70 border border-slate-800/60 p-3 rounded-xl">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Poisson's Ratio (ν)</div>
                    <div className="text-sm font-bold font-mono text-slate-100 mt-1">{selectedMaterial.poissonsRatio}</div>
                  </div>
                  <div className="bg-slate-900/70 border border-slate-800/60 p-3 rounded-xl">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Mass Density (ρ)</div>
                    <div className="text-sm font-bold font-mono text-slate-100 mt-1">{selectedMaterial.density} kg/m³</div>
                  </div>
                  <div className="bg-slate-900/70 border border-slate-800/60 p-3 rounded-xl">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Yield Strength (σy)</div>
                    <div className="text-sm font-bold font-mono text-slate-100 mt-1">{selectedMaterial.tensileStrength} MPa</div>
                  </div>
                  <div className="bg-slate-900/70 border border-slate-800/60 p-3 rounded-xl">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Thermal Conduct. (k)</div>
                    <div className="text-sm font-bold font-mono text-slate-100 mt-1">{selectedMaterial.thermalConductivity} W/(m·K)</div>
                  </div>
                  <div className="bg-slate-900/70 border border-slate-800/60 p-3 rounded-xl">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Electrical Resist. (ρe)</div>
                    <div className="text-sm font-bold font-mono text-slate-100 mt-1">
                      {selectedMaterial.resistivity ? `${selectedMaterial.resistivity} Ω·m` : "Insulator"}
                    </div>
                  </div>
                </div>
              </div>

              {/* Detail action row */}
              <div className="pt-3 border-t border-slate-800 flex gap-2">
                <button
                  onClick={() => {
                    const metrics = `Material Parameter Sheet: ${selectedMaterial.name}\n- Young's Modulus: ${selectedMaterial.youngsModulus} GPa\n- Poisson's Ratio (v): ${selectedMaterial.poissonsRatio}\n- Yield Strength Limit: ${selectedMaterial.tensileStrength} MPa\n- Structural Density: ${selectedMaterial.density} kg/m3\n- Heat Conductivity: ${selectedMaterial.thermalConductivity} W/mK\n- Resistivity: ${selectedMaterial.resistivity || "Insulator"}`;
                    handleCopyClipboard(metrics, `mat-${selectedMaterial.name}`);
                  }}
                  className="flex-1 border border-slate-800 hover:border-amber-500 text-slate-300 font-bold py-2 px-4 rounded-xl text-xs flex justify-center items-center gap-2 cursor-pointer transition-all bg-slate-950/20"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copiedKey === `mat-${selectedMaterial.name}` ? "Copied Properties!" : "Copy Property Spec"}
                </button>
                <button
                  onClick={() => {
                    const metrics = `Material Data Checklist:\n- Name: ${selectedMaterial.name}\n- Young's Modulus: ${selectedMaterial.youngsModulus} GPa\n- Poisson's Ratio (v): ${selectedMaterial.poissonsRatio}\n- Structural Density (ρ): ${selectedMaterial.density} kg/m³\n- Compressive Yield Peak: ${selectedMaterial.tensileStrength} MPa\n- Heat Conductivity (k): ${selectedMaterial.thermalConductivity} W/m·K\n- Description: ${selectedMaterial.description}`;
                    handleExportItem(selectedMaterial.name, metrics);
                  }}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2 px-4 rounded-xl text-xs flex justify-center items-center gap-2 cursor-pointer transition-all"
                >
                  {copiedKey === `export-${selectedMaterial.name}` ? "Exported Portfolio" : "Export Metric to Chat"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* METRIC & IMPERIAL UNIT WORKBENCH */}
        {activeSubTab === "conventions" && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Category selector */}
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 flex flex-col space-y-2">
                <span className="text-[9px] font-mono tracking-wider uppercase text-slate-500">Select physical Dimension</span>
                <div className="flex flex-col gap-1">
                  {CONVERSION_CATEGORIES.map((cat, i) => (
                    <button
                      key={cat.name}
                      onClick={() => {
                        setConvCategoryIndex(i);
                        setConvFromIndex(0);
                        setConvToIndex(1);
                      }}
                      className={`w-full p-2 py-1.5 text-left text-xs font-semibold rounded-lg cursor-pointer transition-all ${
                        convCategoryIndex === i
                          ? "bg-slate-800 text-amber-400"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Left values conversion */}
              <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800 flex flex-col space-y-4">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500">Source Amplitude</span>
                  <input
                    type="number"
                    step="any"
                    value={convVal}
                    onChange={(e) => setConvVal(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-sm text-slate-100 font-mono focus:outline-none focus:border-amber-500 h-10"
                  />
                </div>

                <div className="space-y-2 flex-1">
                  <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500">Source Unit (From)</span>
                  <div className="bg-slate-900 border border-slate-800/80 rounded-xl divide-y divide-slate-800 max-h-32 overflow-y-auto">
                    {currentConvCategory.units.map((u, i) => (
                      <button
                        key={u.name}
                        onClick={() => setConvFromIndex(i)}
                        className={`w-full p-2 py-1.5 text-left text-xs font-medium cursor-pointer flex justify-between items-center ${
                          convFromIndex === i ? "bg-slate-800/60 text-amber-400 font-bold" : "text-slate-400 hover:text-slate-200"
                        }`}
                      >
                        <span>{u.name}</span>
                        <span className="font-mono text-[10px] opacity-70">({u.symbol})</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right values conversions */}
              <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800 flex flex-col space-y-4">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500">Converted Amplitude</span>
                  <div className="w-full bg-slate-900/60 border border-slate-800/80 rounded-xl py-2 px-3 text-sm text-amber-400 font-bold font-mono h-10 flex items-center">
                    {convResult.result.toLocaleString(undefined, { maximumFractionDigits: 5 })} {toUnit?.symbol}
                  </div>
                </div>

                <div className="space-y-2 flex-1">
                  <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500">Target Unit (To)</span>
                  <div className="bg-slate-900 border border-slate-800/80 rounded-xl divide-y divide-slate-800 max-h-32 overflow-y-auto">
                    {currentConvCategory.units.map((u, i) => (
                      <button
                        key={u.name}
                        onClick={() => setConvToIndex(i)}
                        className={`w-full p-2 py-1.5 text-left text-xs font-medium cursor-pointer flex justify-between items-center ${
                          convToIndex === i ? "bg-slate-800/60 text-amber-400 font-bold" : "text-slate-400 hover:text-slate-200"
                        }`}
                      >
                        <span>{u.name}</span>
                        <span className="font-mono text-[10px] opacity-70">({u.symbol})</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Scale visual report */}
            <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 flex flex-col md:flex-row justify-between items-center gap-3">
              <div className="text-center md:text-left">
                <div className="text-[9px] font-mono tracking-wider uppercase text-slate-500">Physical Scale Readout</div>
                <div className="text-sm font-bold font-mono text-emerald-400 mt-0.5">{convResult.scale}</div>
              </div>
              <div className="flex gap-2 w-full md:w-auto">
                <button
                  onClick={() => handleCopyClipboard(convResult.scale, "conv-scale")}
                  className="flex-1 md:flex-initial border border-slate-800 hover:border-amber-500 text-slate-300 px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all hover:bg-slate-900/50 flex items-center justify-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copiedKey === "conv-scale" ? "Copied Scale!" : "Copy Output"}
                </button>
                <button
                  onClick={() => {
                    const report = `Physical Metric Conversion Workspace:\n- Dimension Type: ${currentConvCategory.name}\n- Transformation: ${convVal} ${fromUnit.name} (${fromUnit.symbol}) ➔ ${toUnit.name} (${toUnit.symbol})\n- Scale Result: ${convResult.scale}\n- Mathematical Factor Ratio: ${(toUnit.factor / fromUnit.factor).toFixed(6)}`;
                    handleExportItem(currentConvCategory.name, report);
                  }}
                  className="flex-1 md:flex-initial bg-amber-500 hover:bg-amber-400 text-slate-950 px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-all flex items-center justify-center gap-1"
                >
                  Export Conversation
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
