import React, { useState, useEffect, useRef } from "react";
import {
  MessageSquare,
  Calculator,
  Compass,
  Database,
  Trash2,
  Send,
  Loader2,
  Sparkles,
  Cpu,
  ChevronRight,
  Info,
  Layers,
  ArrowUpRight,
  Bookmark,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { Message } from "./types";
import Calculators from "./components/Calculators";
import ReferenceDesk from "./components/ReferenceDesk";
import ConceptDeconstructor from "./components/ConceptDeconstructor";

const PRESET_PROMPTS = [
  {
    title: "Venturi Nozzle Pressure Drop",
    query: "Calculate the water pressure drop if velocity increases from 1.5 m/s in a 50mm inlet to a 20mm throat. Show formulas and steps.",
    desc: "Fluid mechanics & Bernoulli",
  },
  {
    title: "Stress-Strain of Titan-Grade 5",
    query: "Explain the elastic and yield mechanics of Ti-6Al-4V under standard thermal loads. What physical values limit its structural use?",
    desc: "Materials properties",
  },
  {
    title: "Decaying Transient Vibration",
    query: "An industrial mass damper has m=25kg, k=1500 N/m, c=120 N·s/m. Is this underdamped? Solve for damping ratio and step-by-step frequency.",
    desc: "Vibrations & harmonics",
  },
  {
    title: "Ohm's Law Voltage Dividers",
    query: "Why does connecting a voltmeter in parallel across R2 modify the theoretical output of a passive voltage divider circuit? Show the equivalent resistance formulation.",
    desc: "Electrical circuit loading",
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<"chat" | "calculators" | "deconstructor" | "reference">("chat");

  // Chat parameters
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputVal, setInputVal] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isApiKeyValidated, setIsApiKeyValidated] = useState<boolean | null>(null);

  // Chat listing/Sessions state (local storage backed)
  const [chatHistory, setChatHistory] = useState<{ id: string; title: string; timestamp: string }[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string>("default");

  // Error notifications banner
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Scroll reference for messaging log
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Health check on startup
  useEffect(() => {
    fetch("/api/health")
      .then((res) => res.json())
      .then((data) => {
        setIsApiKeyValidated(data.apiKeyConfigured);
        if (!data.apiKeyConfigured) {
          setErrorMessage(
            "The Gemini API Key is missing. Please configuration keys via the Settings > Secrets workspace widget."
          );
        }
      })
      .catch((err) => {
        console.error("Health check error:", err);
        setIsApiKeyValidated(false);
      });
  }, []);

  // Sync historical chats with localStorage
  useEffect(() => {
    try {
      const storedChats = localStorage.getItem("engiquery_sessions");
      const storedMessaegs = localStorage.getItem(`engiquery_msgs_${activeSessionId}`);

      if (storedChats) {
        setChatHistory(JSON.parse(storedChats));
      } else {
        const defaultSessionObj = { id: "default", title: "Standard Diagnostic Session", timestamp: new Date().toLocaleTimeString() };
        localStorage.setItem("engiquery_sessions", JSON.stringify([defaultSessionObj]));
        setChatHistory([defaultSessionObj]);
      }

      if (storedMessaegs) {
        setMessages(JSON.parse(storedMessaegs));
      } else {
        const welcomeMsg: Message = {
          id: "welcome",
          role: "assistant",
          content: `### Hi, I'm Engiquery. What would you like to build, learn, or solve today? 👋

I am your intelligent engineering and technical assistant. 

Feel free to ask complex physical questions, input load criteria for calculations, or explore our active simulators, calculators, and constants desks using the tabs above!`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        };
        setMessages([welcomeMsg]);
        localStorage.setItem(`engiquery_msgs_${activeSessionId}`, JSON.stringify([welcomeMsg]));
      }
    } catch (e) {
      console.error(e);
    }
  }, [activeSessionId]);

  // Handle autoscroll
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Dispatch message dispatchers
  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isLoading) return;

    const userMsgId = `user-${Date.now()}`;
    const userMsg: Message = {
      id: userMsgId,
      role: "user",
      content: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    // Append to existing
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInputVal("");
    setIsLoading(true);
    setErrorMessage(null);

    // Save user message immediately to local storage
    localStorage.setItem(`engiquery_msgs_${activeSessionId}`, JSON.stringify(updatedMessages));

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          // Pass full chat history mapped to the required payload structure
          messages: updatedMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `Server returned error status ${response.status}`);
      }

      const assistantMsg: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: data.content,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      const finalMessages = [...updatedMessages, assistantMsg];
      setMessages(finalMessages);
      localStorage.setItem(`engiquery_msgs_${activeSessionId}`, JSON.stringify(finalMessages));

      // Auto rename chat session title based on top query if it was named default
      const currentSession = chatHistory.find((c) => c.id === activeSessionId);
      if (currentSession && (currentSession.title.includes("Standard Diagnostic Session") || currentSession.title.includes("New Calculations Node"))) {
        const truncatedTitle = trimmed.length > 28 ? `${trimmed.substring(0, 25)}...` : trimmed;
        const updatedSessions = chatHistory.map((sh) =>
          sh.id === activeSessionId ? { ...sh, title: truncatedTitle } : sh
        );
        setChatHistory(updatedSessions);
        localStorage.setItem("engiquery_sessions", JSON.stringify(updatedSessions));
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "An error occurred during transaction processing.");
    } finally {
      setIsLoading(false);
    }
  };

  // Preset button launcher helper
  const handlePresetTrigger = (promptText: string) => {
    handleSendMessage(promptText);
  };

  // Workspace reset / clear history session
  const handleClearSession = () => {
    localStorage.removeItem(`engiquery_msgs_${activeSessionId}`);
    const welcomeMsg: Message = {
      id: "welcome",
      role: "assistant",
      content: `### Welcome back, Engineer!
Workspace refreshed. Ready for full engineering formulas, stress limits calculations, or concept simplifications.

*What calculations shall we tackle next?*`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages([welcomeMsg]);
    setErrorMessage(null);
  };

  // Append exported reports from sidebar directly into chat text box
  const handleImportExportedText = (reportText: string) => {
    setInputVal((prev) => (prev ? `${prev}\n\n${reportText}` : reportText));
    // Direct trigger set screen active
    setActiveTab("chat");
  };

  // Create new session log
  const handleCreateNewSession = () => {
    const newSessionId = `session-${Date.now()}`;
    const newSessionObj = { id: newSessionId, title: "New Calculations Node", timestamp: new Date().toLocaleTimeString() };
    const updatedSessions = [newSessionObj, ...chatHistory];
    setChatHistory(updatedSessions);
    localStorage.setItem("engiquery_sessions", JSON.stringify(updatedSessions));
    setActiveSessionId(newSessionId);
  };

  const currentSessionName = chatHistory.find((c) => c.id === activeSessionId)?.title || "Calculations Node";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* Top Banner Status Bar */}
      <header className="bg-slate-900 border-b border-slate-800 shrink-0 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-amber-500 text-slate-950 p-2.5 rounded-xl font-display flex items-center justify-center font-bold tracking-tight shadow-md shadow-amber-500/10 hover:scale-[1.02] transition-transform">
              <Cpu className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-extrabold font-display tracking-tight text-slate-100 uppercase">
                  Engiquery
                </h1>
                <span className="bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-[9px] px-1.5 py-0.5 rounded-full font-bold select-none uppercase tracking-wider">
                  STEM AI Suite
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-normal mt-0.5 tracking-tight">AI STEM Assistant & Precision Workstation</p>
            </div>
          </div>

          {/* Tab Navigation Center */}
          <nav className="flex bg-slate-950 border border-slate-800 p-1.5 rounded-xl gap-1">
            <button
              onClick={() => setActiveTab("chat")}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === "chat"
                  ? "bg-slate-850 text-amber-400 border border-slate-700/80 shadow-md"
                  : "text-slate-400 hover:text-slate-200 border border-transparent"
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>STEM Workspace</span>
            </button>
            <button
              onClick={() => setActiveTab("calculators")}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === "calculators"
                  ? "bg-slate-850 text-amber-400 border border-slate-700/80 shadow-md"
                  : "text-slate-400 hover:text-slate-200 border border-transparent"
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Calculators Lab</span>
            </button>
            <button
              onClick={() => setActiveTab("deconstructor")}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === "deconstructor"
                  ? "bg-slate-850 text-amber-400 border border-slate-700/80 shadow-md"
                  : "text-slate-400 hover:text-slate-200 border border-transparent"
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Concept Sandbox</span>
            </button>
            <button
              onClick={() => setActiveTab("reference")}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === "reference"
                  ? "bg-slate-850 text-amber-400 border border-slate-700/80 shadow-md"
                  : "text-slate-400 hover:text-slate-200 border border-transparent"
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Reference Desk</span>
            </button>
          </nav>

          {/* API Key Status Checker */}
          <div className="flex items-center gap-2 select-none">
            <span className="hidden md:inline font-mono text-[10px] text-slate-500">
              {isApiKeyValidated === true ? "API Active" : "No Service Key"}
            </span>
            <div
              className={`w-2.5 h-2.5 rounded-full ${
                isApiKeyValidated === true
                  ? "bg-emerald-500 shadow-md shadow-emerald-500/30"
                  : isApiKeyValidated === false
                  ? "bg-red-500 shadow-md shadow-red-500/30 animate-pulse"
                  : "bg-slate-700"
              }`}
              title={isApiKeyValidated === true ? "Gemini Service connection healthy." : "Checking key configs..."}
            />
          </div>
        </div>
      </header>

      {/* Main Core View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 overflow-hidden flex flex-col">
        {/* Error Notification Banner if any */}
        {errorMessage && (
          <div className="mb-4 flex items-start gap-3 bg-red-950/40 border border-red-900/60 p-3.5 rounded-xl text-xs text-red-350">
            <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold">STEM Engine Fault:</span> {errorMessage}
              {!isApiKeyValidated && apiKeyConfiguredHint()}
            </div>
          </div>
        )}

        {/* Dynamic Display Rendering */}
        <div className="flex-1 min-h-0">
          {activeTab === "chat" && renderEngineeringAIWorkspace()}
          {activeTab === "calculators" && <Calculators onExportToChat={handleImportExportedText} />}
          {activeTab === "deconstructor" && <ConceptDeconstructor onDiscussWithChat={handleImportExportedText} />}
          {activeTab === "reference" && <ReferenceDesk onExportToChat={handleImportExportedText} />}
        </div>
      </main>

      {/* Workspace Footer details */}
      <footer className="bg-slate-950 border-t border-slate-900 py-3 text-center shrink-0">
        <p className="font-mono text-[9px] text-slate-550 select-none uppercase tracking-widest">
          Engiquery • Designed with Absolute Structural Simplicity • Physical Constant Calculations Verifiably Computed
        </p>
      </footer>
    </div>
  );

  function apiKeyConfiguredHint() {
    return (
      <div className="text-[11px] text-slate-400 mt-1 font-normal leading-relaxed">
        Please verify that your Gemini API Key is stored as a secret inside the **Settings &gt; Secrets** workspace tray. Once set, the server connects instantly.
      </div>
    );
  }

  function renderEngineeringAIWorkspace() {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full min-h-0">
        {/* Left Side: Sessions Lists Directory */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-xl flex flex-col h-full min-h-0 select-none max-h-[580px] lg:max-h-none overflow-hidden shadow-xl">
          <div className="p-3 bg-slate-950 border-b border-slate-800 flex justify-between items-center shrink-0">
            <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400 uppercase">Calculation Nodes</span>
            <button
              onClick={handleCreateNewSession}
              className="text-[10px] bg-amber-500 text-slate-950 font-bold px-2 py-1 rounded cursor-pointer hover:bg-amber-400 transition-all uppercase"
            >
              + New Node
            </button>
          </div>

          {/* Session history links */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {chatHistory.length === 0 ? (
              <p className="text-[11px] text-slate-500 text-center py-4">No active nodes.</p>
            ) : (
              chatHistory.map((sess) => (
                <button
                  key={sess.id}
                  onClick={() => setActiveSessionId(sess.id)}
                  className={`w-full p-2.5 text-left rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-all ${
                    activeSessionId === sess.id
                      ? "bg-slate-800 text-amber-400 border border-slate-700/60"
                      : "text-slate-450 hover:text-slate-250 hover:bg-slate-850/40"
                  }`}
                >
                  <Bookmark className="w-3.5 h-3.5 shrink-0" />
                  <div className="truncate flex-1">
                    <div className="truncate font-semibold text-slate-100">{sess.title}</div>
                    <div className="text-[9px] text-slate-500 font-mono mt-0.5">{sess.timestamp}</div>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-650 shrink-0" />
                </button>
              ))
            )}
          </div>

          <div className="p-3 border-t border-slate-850 bg-slate-950/65 flex gap-2 shrink-0">
            <button
              id="clear-workspace-btn"
              onClick={handleClearSession}
              className="flex-1 p-2 bg-slate-900 hover:bg-slate-850 rounded-xl text-xs font-bold text-red-450 border border-slate-850 cursor-pointer flex justify-center items-center gap-1.5 transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear Node
            </button>
          </div>
        </div>

        {/* Center: Thread log workspace */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl flex flex-col h-full min-h-0 shadow-lg overflow-hidden relative">
          {/* Thread Header details */}
          <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex justify-between items-center shrink-0">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <div className="text-xs font-bold tracking-tight text-slate-200 select-text">
                {currentSessionName}
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-1 px-2.5 font-mono text-[9px] text-slate-450 flex items-center gap-1 select-none font-bold">
              <Cpu className="w-3 h-3 text-emerald-400" /> GEMINI-3.5-FLASH
            </div>
          </div>

          {/* Messages list log wrapper */}
          <div className="flex-1 overflow-y-auto p-4 md:p-5 space-y-5 select-text selection:bg-amber-500/30 select-text">
            {messages.map((m) => {
              const isAssistant = m.role === "assistant";
              return (
                <div
                  key={m.id}
                  className={`flex gap-3.5 ${isAssistant ? "justify-start" : "justify-end"}`}
                >
                  {/* Portrait logo icon */}
                  {isAssistant && (
                    <div className="bg-amber-500 text-slate-950 font-bold p-2.5 rounded-xl h-9 w-9 shrink-0 flex items-center justify-center text-sm font-display shadow-md shadow-amber-500/5">
                      EQ
                    </div>
                  )}

                  <div className="max-w-[85%] space-y-1">
                    <div className="flex items-baseline gap-2 px-1">
                      <span className={`text-[10px] font-bold ${isAssistant ? "text-amber-400 uppercase tracking-wider font-mono" : "text-slate-350"}`}>
                        {isAssistant ? "Engiquery Master AI" : "Engineer"}
                      </span>
                      <span className="text-[8px] text-slate-550 font-mono select-none">{m.timestamp}</span>
                    </div>

                    <div
                      className={`p-4 rounded-2xl border leading-relaxed text-xs font-normal font-sans shadow-inner ${
                        isAssistant
                          ? "bg-slate-950/40 border-slate-800/80 text-slate-100"
                          : "bg-slate-800/80 border-slate-700 text-slate-200"
                      }`}
                    >
                      {/* Formatted Text Markdown Renderer */}
                      <div className="markdown-body text-xs prose prose-invert font-normal tracking-wide space-y-2.5">
                        {renderMessageContent(m.content)}
                      </div>
                    </div>
                  </div>

                  {!isAssistant && (
                    <div className="bg-slate-800 text-amber-400 font-bold border border-slate-700 p-2.5 rounded-xl h-9 w-9 shrink-0 flex items-center justify-center text-xs font-mono select-none">
                      EE
                    </div>
                  )}
                </div>
              );
            })}

            {/* Waiting prompt state */}
            {isLoading && (
              <div className="flex gap-3.5 justify-start">
                <div className="bg-amber-500 text-slate-950 font-bold p-2.5 rounded-xl h-9 w-9 shrink-0 flex items-center justify-center text-sm font-display select-none">
                  EQ
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 px-1 selection:bg-none">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider font-mono">Engiquery Engine</span>
                    <Loader2 className="w-3 h-3 text-amber-500 animate-spin" />
                  </div>
                  <div className="bg-slate-950/20 border border-slate-850 p-4 rounded-2xl text-slate-400 text-xs flex items-center gap-2 italic">
                    Analyzing calculations constraints and compiling solution parameters...
                  </div>
                </div>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Form write panel */}
          <div className="p-3 border-t border-slate-850 bg-slate-950/30 shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputVal);
              }}
              className="flex gap-2 items-end relative"
            >
              <textarea
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage(inputVal);
                  }
                }}
                placeholder="Ask technical questions, input stress criteria, request Ohm divider formulas..."
                rows={1}
                className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl p-3 pr-10 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 font-sans resize-none max-h-24 h-10 overflow-y-auto leading-normal"
              />
              <button
                type="submit"
                disabled={!inputVal.trim() || isLoading}
                className="absolute right-2.5 bottom-2.5 text-amber-500 hover:text-amber-400 disabled:text-slate-650 cursor-pointer p-0.5"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Right Side: Preset Launchers Panel */}
        <div className="lg:col-span-1 flex flex-col gap-5 min-h-0 select-none max-h-[580px] lg:max-h-none overflow-y-auto">
          {/* Presets block */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col h-full min-h-0 space-y-3.5 shadow-md">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase font-bold">Concept Presets</span>
              <h3 className="text-slate-100 font-bold text-xs tracking-tight mt-0.5">Quick Engineering Challenges</h3>
              <p className="text-slate-400 text-[10.5px] font-normal leading-normal mt-1">
                Select a preset calculation or deconstruct physical limits.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2.5 flex-1 overflow-y-auto pr-1">
              {PRESET_PROMPTS.map((pres) => (
                <button
                  key={pres.title}
                  onClick={() => handlePresetTrigger(pres.query)}
                  className="w-full text-left p-3 rounded-xl border border-slate-800 bg-slate-950/30 hover:border-amber-500 hover:bg-slate-950/70 cursor-pointer transition-all group flex flex-col justify-between"
                >
                  <div className="flex justify-between items-start gap-1 w-full">
                    <span className="font-bold text-slate-200 text-[11px] group-hover:text-amber-400 transition-colors leading-tight">{pres.title}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-amber-500 transition-colors shrink-0" />
                  </div>
                  <div className="text-[9.5px] text-slate-500 mt-1 truncate w-full">{pres.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Pure custom helper renderer for markdown structures (since react-markdown performs beautifully)
  function renderMessageContent(content: string) {
    // Custom parsing helper to keep rendering clean, error-safe, and visually styled without complex imports.
    // Handles markdown lists, bold terms, headers, and bullet lines nicely.
    const lines = content.split("\n");
    return lines.map((line, idx) => {
      // Header check
      if (line.startsWith("### ")) {
        return (
          <h4 key={idx} className="text-sm font-extrabold text-slate-100 mt-4 mb-2 tracking-tight">
            {line.replace("### ", "")}
          </h4>
        );
      }
      if (line.startsWith("## ")) {
        return (
          <h3 key={idx} className="text-base font-extrabold text-amber-400 mt-5 mb-2.5 tracking-tight border-b border-slate-800 pb-1 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-amber-500" /> {line.replace("## ", "")}
          </h3>
        );
      }
      if (line.startsWith("# ")) {
        return (
          <h2 key={idx} className="text-lg font-extrabold text-amber-400 mt-6 mb-3 tracking-tight border-b border-slate-800 pb-1">
            {line.replace("# ", "")}
          </h2>
        );
      }
      // Equation / Code block line
      if (line.startsWith("```") || line.trim().startsWith("```")) {
        return null; // simply skip boundary lines for raw text rendering within codeblocks
      }
      // Bullet list item
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        const rawText = line.trim().substring(2);
        return (
          <div key={idx} className="flex items-start gap-2.5 pl-2 my-1 text-slate-300">
            <span className="text-amber-500 text-sm leading-none shrink-0">•</span>
            <span className="leading-relaxed font-normal">{parseInlineFormatting(rawText)}</span>
          </div>
        );
      }
      // Numbered List
      const numMatch = line.trim().match(/^(\d+)\.\s(.*)/);
      if (numMatch) {
        return (
          <div key={idx} className="flex items-start gap-2 pl-2 my-1.5 text-slate-300">
            <span className="font-mono text-[9px] font-extrabold text-amber-400 border border-amber-500/20 bg-amber-500/5 p-0.5 px-1 rounded mr-1 select-none">
              {numMatch[1]}
            </span>
            <span className="leading-relaxed font-normal">{parseInlineFormatting(numMatch[2])}</span>
          </div>
        );
      }
      // Equation block background
      if (line.includes("=") && (line.includes("+") || line.includes("-") || line.includes("×") || line.includes("÷") || line.includes("/") || line.includes("*") || line.includes("√"))) {
        if (!line.startsWith(" ") && line.length < 120 && !line.includes("http") && !line.includes("Welcome")) {
          return (
            <div key={idx} className="bg-slate-950/80 border border-slate-850 p-2.5 px-4 rounded-xl font-mono text-[11px] text-amber-400 my-2.5 leading-normal overflow-x-auto select-all max-w-full font-extrabold">
              {line}
            </div>
          );
        }
      }

      // Plain paragraph
      if (!line.trim()) return <div key={idx} className="h-2" />;
      return (
        <p key={idx} className="leading-relaxed font-normal text-slate-300 select-text font-sans font-normal text-slate-300">
          {parseInlineFormatting(line)}
        </p>
      );
    });
  }

  // Parse inline formatting: **bold**
  function parseInlineFormatting(str: string): React.ReactNode {
    if (!str.includes("**")) return str;
    const parts = str.split("**");
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return (
          <strong key={i} className="text-amber-400 font-extrabold">
            {part}
          </strong>
        );
      }
      return part;
    });
  }
}
