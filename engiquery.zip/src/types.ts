export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export interface SavedCalculation {
  id: string;
  title: string;
  category: string;
  inputs: Record<string, number>;
  outputs: Record<string, any>;
  formula: string;
  timestamp: string;
}

export interface ScienceConstant {
  name: string;
  symbol: string;
  value: string;
  unit: string;
  category: "Physics" | "Chemistry" | "Mathematics" | "Materials";
  description: string;
}

export interface UnitConversionCategory {
  name: string;
  units: { name: string; symbol: string; factor: number; baseOffset?: number }[];
}
