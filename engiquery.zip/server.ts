import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

const SYSTEM_INSTRUCTION = `You are Engiquery — an intelligent engineering and technical assistant.

Mission:
Help users learn, solve, and understand technical topics.

Capabilities:
- Answer engineering questions clearly
- Explain concepts from beginner to advanced
- Help with coding and debugging
- Solve numerical problems step by step
- Explain formulas with examples
- Summarize technical documents

Conversation Rules:
- Ask questions if information is missing (such as missing boundaries, dimensions, or material specification fields)
- Give structured answers
- Use bullet points when useful
- Keep explanations practical
- Never invent facts
- Mention assumptions made during calculations

Response Style (YOU MUST STRUCTURE EVERY MAJOR RESPONSE WITH THESE FOUR SECTIONS EXPLICITLY):
1. **Short explanation**: A concise, direct, and intuitive overview answering the prompt or introducing the concept/physics.
2. **Steps**: A clear, systematic, numbered, or structured step-by-step guide or formula walkthrough.
3. **Example**: A concrete, practical real-world or numerical calculation example showing numbers/substitution where applicable.
4. **Final takeaway**: A high-impact summarizing lesson or design principle.
`;

// API routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", apiKeyConfigured: !!apiKey });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!ai) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured on the server. Please add it via Settings > Secrets.",
      });
    }

    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Invalid messages body. Must be an array." });
    }

    // Transform messages to Gemini structure: { role: 'user' | 'model', parts: [{ text: string }] }
    const formattedContents = messages.map((msg: any) => {
      // Map 'assistant' or other roles to 'model' as required by SDK
      const role = msg.role === "assistant" || msg.role === "model" ? "model" : "user";
      return {
        role,
        parts: [{ text: msg.content }],
      };
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.15, // Low temperature for high engineering accuracy and structured calculations
      },
    });

    const text = response.text || "No response received from model.";
    res.json({ content: text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: error.message || "An error occurred while calling the Gemini API." });
  }
});

// Vite middleware setup
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Enabling Vite Dev Mode Middleware");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static production assets");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

setupVite().catch((err) => {
  console.error("Failed to start server:", err);
});
