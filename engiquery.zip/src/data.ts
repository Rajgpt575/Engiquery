import { ScienceConstant } from "./types";

export const ENGINEERING_CONSTANTS: ScienceConstant[] = [
  {
    name: "Acceleration of Gravity",
    symbol: "g",
    value: "9.80665",
    unit: "m/s²",
    category: "Physics",
    description: "Standard gravitational acceleration at the Earth's surface (approximately 32.174 ft/s²).",
  },
  {
    name: "Speed of Light in Vacuum",
    symbol: "c",
    value: "2.99792e8",
    unit: "m/s",
    category: "Physics",
    description: "The fundamental physical constant representing the maximum speed at which energy or information can travel.",
  },
  {
    name: "Universal Gas Constant",
    symbol: "R",
    value: "8.31446",
    unit: "J/(mol·K)",
    category: "Chemistry",
    description: "Constant featured in the Ideal Gas Law equation: P·V = n·R·T.",
  },
  {
    name: "Planck Constant",
    symbol: "h",
    value: "6.62607e-34",
    unit: "J·s",
    category: "Physics",
    description: "Quantizes electromagnetic radiation, linking photon energy to its frequency (E = h·f).",
  },
  {
    name: "Boltzmann Constant",
    symbol: "k_B",
    value: "1.380649e-23",
    unit: "J/K",
    category: "Physics",
    description: "Relates kinetic energy of gas particles to temperature.",
  },
  {
    name: "Avogadro Number",
    symbol: "N_A",
    value: "6.02214e23",
    unit: "mol⁻¹",
    category: "Chemistry",
    description: "Number of constituent particles in one mole of a substance.",
  },
  {
    name: "Stefan-Boltzmann Constant",
    symbol: "σ",
    value: "5.67037e-8",
    unit: "W/(m²·K⁴)",
    category: "Physics",
    description: "Proportionality constant in the Stefan-Boltzmann blackbody radiation law.",
  },
  {
    name: "Permittivity of Free Space",
    symbol: "ε_0",
    value: "8.854187e-12",
    unit: "F/m",
    category: "Physics",
    description: "Capability of an electric field to permeate a vacuum (electric constant).",
  },
  {
    name: "Permeability of Free Space",
    symbol: "μ_0",
    value: "1.256637e-6",
    unit: "H/m",
    category: "Physics",
    description: "Magnetic constant describing vacuum magnetization potential (4π × 10⁻⁷ H/m).",
  },
  {
    name: "Faraday Constant",
    symbol: "F",
    value: "96485.33",
    unit: "C/mol",
    category: "Chemistry",
    description: "Total electric charge carried by one mole of electrons.",
  },
  {
    name: "Gravitational Constant",
    symbol: "G",
    value: "6.6743e-11",
    unit: "m³/(kg·s²)",
    category: "Physics",
    description: "Empirical physical constant in Isaac Newton's law of universal gravitation.",
  },
  {
    name: "Pi Ratio",
    symbol: "π",
    value: "3.14159265",
    unit: "dimensionless",
    category: "Mathematics",
    description: "The mathematical constant representing the ratio of a circle's circumference to its diameter.",
  }
];

export interface MaterialProperty {
  name: string;
  density: string;          // kg/m³
  youngsModulus: string;    // GPa
  tensileStrength: string;  // MPa
  thermalConductivity: string; // W/(m·K)
  resistivity?: string;     // Ω·m
  poissonsRatio: string;
  description: string;
}

export const MATERIAL_DATABASE: MaterialProperty[] = [
  {
    name: "Structural Steel (A36)",
    density: "7850",
    youngsModulus: "200",
    tensileStrength: "400",
    thermalConductivity: "50",
    resistivity: "1.7e-7",
    poissonsRatio: "0.26",
    description: "Standard structural alloy widely used for building supports, rivets, columns, and general engineering construction."
  },
  {
    name: "Aluminum (6061-T6)",
    density: "2700",
    youngsModulus: "68.9",
    tensileStrength: "310",
    thermalConductivity: "167",
    resistivity: "3.9e-8",
    poissonsRatio: "0.33",
    description: "Precipitation-hardened structural aluminum alloy. Exceptional strength-to-weight ratio, excellent corrosion resistance, and easily welded."
  },
  {
    name: "Copper (Oxygen-Free C101)",
    density: "8960",
    youngsModulus: "117",
    tensileStrength: "220",
    thermalConductivity: "391",
    resistivity: "1.68e-8",
    poissonsRatio: "0.34",
    description: "Standard electrical copper grade. Highest thermal and electrical conductivity of commercial metals, making it critical for electrical engineering."
  },
  {
    name: "Titanium (Grade 5, Ti-6Al-4V)",
    density: "4430",
    youngsModulus: "113.8",
    tensileStrength: "950",
    thermalConductivity: "6.7",
    resistivity: "1.78e-6",
    poissonsRatio: "0.342",
    description: "Alpha-beta titanium alloy combining high mechanical strength, lightweight structure, remarkable toughness, and severe corrosion resistance."
  },
  {
    name: "Structural Concrete (Standard Class C)",
    density: "2400",
    youngsModulus: "30",
    tensileStrength: "4", // Low tensile (unreinforced)
    thermalConductivity: "1.5",
    poissonsRatio: "0.20",
    description: "Brittle aggregate bonding composite. Strong in compression (approx 30MPa) but highly vulnerable to mechanical tension, demanding steel rebar reinforcements."
  },
  {
    name: "Stainless Steel (Grade 304)",
    density: "8000",
    youngsModulus: "193",
    tensileStrength: "505",
    thermalConductivity: "16.2",
    resistivity: "7.2e-7",
    poissonsRatio: "0.29",
    description: "Classic chromium-nickel austenitic stainless steel. Highly resistant to chemical rusting, chemical acidity, and high-temperature oxidation stresses."
  }
];

export const CONVERSION_CATEGORIES = [
  {
    name: "Length",
    units: [
      { name: "Meter", symbol: "m", factor: 1 },
      { name: "Millimeter", symbol: "mm", factor: 1000 },
      { name: "Centimeter", symbol: "cm", factor: 100 },
      { name: "Kilometer", symbol: "km", factor: 0.001 },
      { name: "Foot", symbol: "ft", factor: 3.28084 },
      { name: "Inch", symbol: "in", factor: 39.3701 },
      { name: "Mile", symbol: "mi", factor: 0.000621371 },
      { name: "Yard", symbol: "yd", factor: 1.09361 }
    ]
  },
  {
    name: "Pressure",
    units: [
      { name: "Pascal", symbol: "Pa", factor: 1 },
      { name: "KiloPascal", symbol: "kPa", factor: 0.001 },
      { name: "MegaPascal", symbol: "MPa", factor: 0.000001 },
      { name: "Atmosphere", symbol: "atm", factor: 0.00000986923 },
      { name: "Bar", symbol: "bar", factor: 0.00001 },
      { name: "PSI (lb/in²)", symbol: "psi", factor: 0.000145038 },
      { name: "Millibar", symbol: "mbar", factor: 0.01 }
    ]
  },
  {
    name: "Energy",
    units: [
      { name: "Joule", symbol: "J", factor: 1 },
      { name: "KiloJoule", symbol: "kJ", factor: 0.001 },
      { name: "Watt-hour", symbol: "Wh", factor: 0.000277778 },
      { name: "Kilowatt-hour", symbol: "kWh", factor: 2.77778e-7 },
      { name: "Calorie", symbol: "cal", factor: 0.239006 },
      { name: "BTU", symbol: "BTU", factor: 0.000947817 },
      { name: "Electronvolt", symbol: "eV", factor: 6.242e18 }
    ]
  },
  {
    name: "Power",
    units: [
      { name: "Watt", symbol: "W", factor: 1 },
      { name: "Kilowatt", symbol: "kW", factor: 0.001 },
      { name: "Megawatt", symbol: "MW", factor: 0.000001 },
      { name: "Horsepower (mechanical)", symbol: "hp", factor: 0.00134102 },
      { name: "BTU/hour", symbol: "BTU/hr", factor: 3.412142 },
      { name: "Calories/second", symbol: "cal/s", factor: 0.239006 }
    ]
  },
  {
    name: "Mass",
    units: [
      { name: "Kilogram", symbol: "kg", factor: 1 },
      { name: "Gram", symbol: "g", factor: 1000 },
      { name: "Pound", symbol: "lb", factor: 2.20462 },
      { name: "Ounce", symbol: "oz", factor: 35.274 },
      { name: "Metric Ton", symbol: "tonne", factor: 0.001 },
      { name: "Slug", symbol: "slug", factor: 0.0685218 }
    ]
  }
];
