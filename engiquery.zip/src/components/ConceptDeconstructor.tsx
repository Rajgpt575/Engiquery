import React, { useState } from "react";
import { Lightbulb, Variable, Box, GraduationCap, ArrowRight, MessageSquare, Check, AlertCircle } from "lucide-react";

interface ConceptDeconstructorProps {
  onDiscussWithChat: (text: string) => void;
}

export default function ConceptDeconstructor({ onDiscussWithChat }: ConceptDeconstructorProps) {
  const [activeConcept, setActiveConcept] = useState<"bernoulli" | "fourier" | "beam" | "entropy">("bernoulli");

  // Physics dynamic sliders
  const [venturiVelocity, setVenturiVelocity] = useState<number>(3); // Bernoulli fluid velocity (m/s)
  const [fourierFreq, setFourierFreq] = useState<number>(2); // Fourier frequency (Hz)
  const [entropyP, setEntropyP] = useState<number>(0.5); // Shannon Probability slider

  // Quiz states
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showQuizResult, setShowQuizResult] = useState<Record<string, boolean>>({});

  const handleQuizAnswer = (conceptId: string, answerIdx: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [conceptId]: answerIdx }));
    setShowQuizResult((prev) => ({ ...prev, [conceptId]: true }));
  };

  const currentLauncherDiscuss = (conceptTitle: string, formula: string) => {
    onDiscussWithChat(
      `Hi Engiquery, can you explain the intuitive concept behind [${conceptTitle}]? Specifically, walk me through how the formula: \`${formula}\` correlates deeply to real-world design, and provide another practical calculation sample.`
    );
  };

  // Concept Data & deconstructions
  const CONCEPT_CATALOG = {
    bernoulli: {
      title: "Bernoulli's Principle",
      formula: "P + ½•ρ•v² + ρ•g•h = Constant",
      layman: "Think of pressure and fluid velocity like lanes of traffic on a highway. When the lanes get constricted (narrower), the fluid is forced to speed up (accelerate) to squeeze through, but its internal sideways pressure decreases, as it directs its kinetic energy forward rather than outwards against the tube walls.",
      variables: [
        { symbol: "P", name: "Absolute Pressure", unit: "Pascals (Pa)", desc: "The static physical pressure exerted sideways on flow boundary walls." },
        { symbol: "ρ (rho)", name: "Fluid Density", unit: "kg/m³", desc: "The mass concentration factor (constant for incompressible fluids)." },
        { symbol: "v", name: "Velocity", unit: "m/s", desc: "The speed of fluid movement along the pipe axial length." },
        { symbol: "g", name: "Gravitational constant", unit: "m/s²", desc: "Local acceleration due to planetary gravity." },
        { symbol: "h", name: "Elevation height", unit: "meters (m)", desc: "Fluid height index from a relative standard datum level." }
      ],
      caseStudy: "Designing modern commercial airplane wings (Camber curve causes faster airflow overhead, resulting in localized lower pressure and aerodynamic upward lift) or high-efficiency chemical Venturi fuel injectors.",
      quiz: {
        question: "When fluid enters a constricted nozzle, what fundamental behavior happens to its pressure and velocity?",
        options: [
          "Pressure increases, velocity decreases",
          "Pressure decreases, velocity increases",
          "Both pressure and velocity increase linearly",
          "Both pressure and velocity drop to zero"
        ],
        correct: 1, // index 1
        explanation: "Correct! To conserve mass, fluid must accelerate (greater velocity) through narrow openings, converting its potential thermal/pressure energy into kinetic energy (lower pressure)."
      }
    },
    fourier: {
      title: "Fourier Transform Analysis",
      formula: "X(f) = ∫ x(t)•e^-(i•2π•f•t) dt",
      layman: "Imagine tasting a gourmet mixed soup. Your mouth immediately distinguishes individual separate elements—salt, garlic, ginger, and basil. The Fourier Transform does exactly this but for engineering waves! It acts as a prism, decomposing any complex messy, time-based signal into its fundamental separate pure musical notes (frequencies) and amplitude amounts.",
      variables: [
        { symbol: "X(f)", name: "Frequency Spectrum", unit: "Complex Amplitude", desc: "The resulting output displaying frequencies and phase parameters." },
        { symbol: "x(t)", name: "Time Domain Signal", unit: "Physical Unit (V, Pa, etc)", desc: "The raw real-world signal recorded over continuous time scale." },
        { symbol: "t", name: "Time index", unit: "seconds (s)", desc: "The progression axis representing the recording timescale." },
        { symbol: "f", name: "Frequency identifier", unit: "Hertz (Hz)", desc: "The target cyclic frequency component analyzed in the integral." },
        { symbol: "i", name: "Imaginary unit", unit: "√-1", desc: "Provides structural phase rotation context for cyclic oscillations." }
      ],
      caseStudy: "Decomposing active vibration signals from physical heavy-duty rotational turbines to identify microscopic bearing wears before catastrophic failures, or MP3/JPEG file size compression algorithms.",
      quiz: {
        question: "What physical representation does the 'Frequency Domain' output shift our coordinates to?",
        options: [
          "Changes signal values relative to geographic latitude coordinates",
          "Plots signal amplitudes across individual cyclic rate frequencies",
          "Tracks raw signal history across absolute timeline durations",
          "Projects stress-strain patterns relative to concrete aggregates"
        ],
        correct: 1,
        explanation: "Correct! The Fourier Transform moves coordinates out of the timescale and represents them relative to cyclic rates (Hertz, rad/s) so noise peaks can be isolated."
      }
    },
    beam: {
      title: "Euler-Bernoulli Beam Deflection",
      formula: "EI • (d⁴w/dx⁴) = q(x)",
      layman: "Think of a heavy suspension bridge beam bending. The beam's resistance to flexing is a constant fight between two core titans: the material strength itself (Young's Modulus E) and how the metal is physically shaped (Moment of Inertia I, e.g. placing metal into a tall 'I-Beam' shape rather than a flat piece of sheet metal to vastly resist vertical gravity shear).",
      variables: [
        { symbol: "E", name: "Young's Modulus", unit: "GPascals / Pascals", desc: "The material stiffness coefficient; resists atomic mechanical strains." },
        { symbol: "I", name: "Area Moment of Inertia", unit: "meters⁴ (m⁴)", desc: "The geometric structural distribution; measures resistance against bending shear." },
        { symbol: "w(x)", name: "Elastic deflection line", unit: "meters (m)", desc: "The variable deflection displacement downward at length coordinate x." },
        { symbol: "q(x)", name: "Continuous Load density", unit: "Newtons/meter (N/m)", desc: "The applied structural weight function distribution profile." },
        { symbol: "EI", name: "Flexural Rigidity", unit: "N·m²", desc: "The final aggregate stiffness property combining material and physical structure." }
      ],
      caseStudy: "Calculating stress safety boundaries for high-rise steel column rafters and highway overpass construction girders under severe heavy freight trucking gridlocks.",
      quiz: {
        question: "Why do structural civil engineers build vertical rungs in structural 'I-Beams' instead of flat layout blocks?",
        options: [
          "To reduce chemical rusting coefficients",
          "To raise the Area Moment of Inertia (I) against gravity bending, using less material",
          "To reduce gravitational acceleration g localized in foundations",
          "To balance electrical resistivity within concrete aggregate structures"
        ],
        correct: 1,
        explanation: "Correct! Putting structural metal material far from the neutral axis drastically multiplies Area Moment of Inertia (I), providing extreme structural strength with lightweight efficiency."
      }
    },
    entropy: {
      title: "Shannon's Information Entropy",
      formula: "H(X) = -Σ P(x_i)•log₂(P(x_i))",
      layman: "Imagine flipping a weighted coin. If the coin has heads on both sides list parameters, there is no surprise (entropy is 0). If the coin is completely fair, you have absolute uncertainty—each flip is a mystery (entropy is maximum at 1 bit). Shannon's Entropy measures this exact volume of 'shattered surprise' or uncertainty, telling communications engineers how much actual raw space is needed to transmit messages safely over radio fields.",
      variables: [
        { symbol: "H(X)", name: "Information Entropy", unit: "Bits / Shannons", desc: "The standard metric density representing raw average system uncertainty." },
        { symbol: "P(x_i)", name: "Probability", unit: "Normalized (0 to 1)", desc: "The structural statistical chance of event i occurring." },
        { symbol: "log₂", name: "Base-2 logarithm", unit: "Mathematical", desc: "Translates random possibilities into physical binary communication bits." },
        { symbol: "X", name: "Random variable", unit: "Set systems", desc: "The collection catalog of possible physical states or message pieces." }
      ],
      caseStudy: "Formulating optimal data compression codecs like ZIP files (eliminating predictable repeats) or setting physical network bounds for satellite routers transmitting signals under heavy thermal solar noise.",
      quiz: {
        question: "At what statistical probability distribution does a binary signal reach its absolute maximum entropy level?",
        options: [
          "When the event is completely guaranteed (Probability = 1.0)",
          "When the event is mathematically impossible (Probability = 0.0)",
          "At equal likelihood (Probability = 0.5)",
          "When the log base is scaled from bits to metric Joules"
        ],
        correct: 2,
        explanation: "Correct! Absolute 50/50 split probability creates maximum mathematical uncertainty, yielding exactly 1.0 bit of Shannon Entropy."
      }
    }
  };

  const selectedConcept = CONCEPT_CATALOG[activeConcept];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-full shadow-2xl">
      {/* Category header */}
      <div className="bg-slate-950 border-b border-slate-800 p-2 flex flex-wrap gap-1 items-center">
        {(["bernoulli", "fourier", "beam", "entropy"] as const).map((key) => (
          <button
            key={key}
            onClick={() => setActiveConcept(key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
              activeConcept === key
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-slate-150 hover:bg-slate-800"
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5 inline mr-1.5" />
            {CONCEPT_CATALOG[key].title}
          </button>
        ))}
      </div>

      <div className="flex-1 p-5 overflow-y-auto grid grid-cols-1 xl:grid-cols-2 gap-6 select-none">
        {/* Left pane: Plain explanation & Variables */}
        <div className="space-y-4">
          <div>
            <span className="text-[10px] font-mono tracking-widest text-[#f59e0b] uppercase font-bold">Concept Deconstructor</span>
            <h3 className="text-slate-100 font-extrabold text-lg tracking-tight mt-0.5">{selectedConcept.title}</h3>
            <div className="mt-1 bg-slate-950 border border-slate-800/80 p-2 px-3.5 rounded-lg inline-block font-mono text-xs text-amber-400 font-extrabold">
              {selectedConcept.formula}
            </div>
          </div>

          <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-4 space-y-2">
            <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1">
              <Lightbulb className="w-4 h-4 text-amber-400" /> Ground Intuition (Simple Analogy)
            </h4>
            <p className="text-slate-350 text-[11px] leading-relaxed font-normal">{selectedConcept.layman}</p>
          </div>

          {/* Variable breakdown */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Variable className="w-4 h-4 text-amber-500" /> Variable Deconstruction
            </h4>
            <div className="bg-slate-950 border border-slate-800/60 rounded-xl divide-y divide-slate-850/60 overflow-hidden text-[11px]">
              {selectedConcept.variables.map((v) => (
                <div key={v.symbol} className="p-2.5 px-4 flex gap-4 hover:bg-slate-900/40 transition-all">
                  <div className="font-mono text-amber-400 font-bold text-sm w-12 shrink-0">{v.symbol}</div>
                  <div>
                    <span className="font-bold text-slate-200">{v.name}</span>{" "}
                    <span className="font-mono text-[9px] text-slate-500">[{v.unit}]</span>
                    <p className="text-slate-400 text-[10.5px] mt-0.5 font-normal">{v.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right pane: Interactive sandbox & Sandbox actions */}
        <div className="space-y-5 flex flex-col justify-between">
          {/* Interactive Physics sandbox */}
          <div className="bg-slate-950 border border-slate-850 rounded-xl p-4 flex flex-col min-h-[220px] justify-between relative overflow-hidden">
            <span className="absolute top-2 left-2 text-[9px] font-mono tracking-widest text-slate-500 flex items-center gap-1 uppercase select-none">
              <Box className="w-3.5 h-3.5 text-amber-500" /> Interactive Physics Sandbox
            </span>

            {/* SANDBOX: BERNOULLI FLOW */}
            {activeConcept === "bernoulli" && (
              <div className="flex-1 flex flex-col justify-end pt-8 space-y-4">
                {/* SVG graphics Venturi */}
                <div className="flex-1 flex justify-center items-center h-28 relative">
                  <svg className="w-full h-full" viewBox="0 0 320 100">
                    {/* Air particles */}
                    <path
                      d="M 10 50 L 310 50"
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth={1}
                      strokeDasharray={`${6 * venturiVelocity} ${Math.max(2, 20 - venturiVelocity * 3)}`}
                      className="opacity-40"
                    />
                    {/* Metal pipes */}
                    <path
                      d="M 10 20 L 100 20 C 130 20, 130 40, 160 40 C 190 40, 190 20, 220 20 L 310 20 M 10 80 L 100 80 C 130 80, 130 60, 160 60 C 190 60, 190 80, 220 80 L 310 80"
                      fill="none"
                      stroke="#475569"
                      strokeWidth={3.5}
                    />
                    {/* Fluid gauges */}
                    {/* Gauge 1 (Wide entrance - low velocity = high static pressure) */}
                    <line x1="75" y1="20" x2="75" y2="40" stroke="#f87171" strokeWidth="2" />
                    <rect x="70" y="4" width="10" height="15" fill="#f87171" opacity="0.8" />
                    <text x="75" y="-5" fill="#f87171" fontSize="8" fontFamily="monospace" textAnchor="middle">High P1</text>

                    {/* Gauge 2 (Narrow nozzle - high velocity = low static pressure) */}
                    <line x1="160" y1="40" x2="160" y2={50 + venturiVelocity * 3} stroke="#f59e0b" strokeWidth="2" />
                    <rect x="155" y={35 + venturiVelocity * 3} width="10" height="15" fill="#f59e0b" opacity="0.8" />
                    <text x="160" y="19" fill="#f59e0b" fontSize="8" fontFamily="monospace" textAnchor="middle">Low P2</text>
                  </svg>
                </div>

                {/* Input controllers */}
                <div className="space-y-1 bg-slate-900 border border-slate-800/80 px-3.5 py-2 rounded-xl">
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>Inlet Velocity (v1): <span className="text-amber-400 font-bold">{venturiVelocity} m/s</span></span>
                    <span>Nozzle Speed (v2): <span className="text-amber-400 font-bold">{(venturiVelocity * 2.2).toFixed(1)} m/s</span></span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="8"
                    step="0.5"
                    value={venturiVelocity}
                    onChange={(e) => setVenturiVelocity(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 bg-slate-800 rounded"
                  />
                </div>
              </div>
            )}

            {/* SANDBOX: FOURIER PRISM */}
            {activeConcept === "fourier" && (
              <div className="flex-1 flex flex-col justify-end pt-8 space-y-4">
                <div className="flex-1 grid grid-cols-2 gap-4 h-28">
                  {/* Time Domain wave */}
                  <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 relative flex flex-col justify-between">
                    <span className="text-[8px] font-mono text-slate-500 absolute top-1 right-1">TIME DOMAIN</span>
                    <svg className="w-full h-4/5 self-end" viewBox="0 0 140 60">
                      {/* Midline */}
                      <line x1="0" y1="30" x2="140" y2="30" stroke="#1e293b" strokeWidth="1" strokeDasharray="2" />
                      {/* Wave drawing */}
                      <path
                        d={Array.from({ length: 140 }, (_, x) => {
                          const t = x / 140;
                          const y = 30 - 20 * Math.sin(2 * Math.PI * fourierFreq * t);
                          return `${x === 0 ? "M" : "L"} ${x} ${y}`;
                        }).join(" ")}
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="1.5"
                      />
                    </svg>
                  </div>

                  {/* Frequency Domain peak */}
                  <div className="bg-slate-900 rounded-xl border border-slate-800 p-2 relative flex flex-col justify-between">
                    <span className="text-[8px] font-mono text-slate-500 absolute top-1 right-1">FREQUENCY SPEC</span>
                    <svg className="w-full h-4/5 self-end" viewBox="0 0 140 60">
                      <line x1="0" y1="50" x2="140" y2="50" stroke="#1e293b" strokeWidth="1" />
                      {/* Frequency bar peak */}
                      <rect
                        x={20 + fourierFreq * 14}
                        y={50 - 40}
                        width="4"
                        height="40"
                        fill="#f59e0b"
                        rx="1"
                      />
                      <text x={22 + fourierFreq * 14} y={50 - 44} fill="#f59e0b" fontSize="8" fontFamily="monospace" textAnchor="middle">
                        {fourierFreq}Hz
                      </text>
                    </svg>
                  </div>
                </div>

                <div className="space-y-1 bg-slate-900 border border-slate-800 px-3.5 py-2 rounded-xl">
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>Input Wave Frequency (f): <span className="text-amber-400 font-bold">{fourierFreq} Hz</span></span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="7"
                    step="1"
                    value={fourierFreq}
                    onChange={(e) => setFourierFreq(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 bg-slate-800 rounded"
                  />
                </div>
              </div>
            )}

            {/* SANDBOX: EULER BEAM */}
            {activeConcept === "beam" && (
              <div className="flex-1 flex flex-col justify-end pt-8 space-y-4">
                <div className="flex-1 flex justify-center items-center h-28">
                  <svg className="w-4/5 h-full" viewBox="0 0 200 100">
                    {/* Beam bounds shape */}
                    {/* Animate moment of inertia depth */}
                    <rect x="40" y="30" width="120" height="12" fill="#334155" stroke="#475569" strokeWidth="1" />
                    {/* Tall shape vs flat shape representation */}
                    <rect x="100" y="55" width="12" height="30" fill="none" stroke="#22c55e" strokeWidth="2.5" />
                    <text x="117" y="73" fill="#22c55e" fontSize="8" fontFamily="monospace">Area Moment I = base•H³ / 12</text>
                  </svg>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-center text-[10.5px] font-mono leading-relaxed text-slate-400">
                  Deflection decreases by <span className="text-amber-400 font-extrabold font-mono">H cubed (H³)</span>. Doubling beam vertical thickness drops maximum deflection distance by <span className="text-amber-400 font-extrabold">8 times!</span>
                </div>
              </div>
            )}

            {/* SANDBOX: SHANNON ENTROPY */}
            {activeConcept === "entropy" && (
              <div className="flex-1 flex flex-col justify-end pt-8 space-y-4">
                <div className="flex-1 flex justify-center items-center h-28 relative">
                  <svg className="w-4/5 h-full" viewBox="0 0 200 80">
                    {/* Plot Entropy Curve: H = -p*log(p) - (1-p)*log(1-p) */}
                    <path
                      d={Array.from({ length: 101 }, (_, idx) => {
                        const p = idx / 100;
                        if (p === 0 || p === 1) return `L ${idx * 2} 70`;
                        const h = -(p * Math.log2(p) + (1 - p) * Math.log2(1 - p));
                        const y = 70 - h * 55;
                        return `${idx === 0 ? "M" : "L"} ${idx * 2} ${y}`;
                      }).join(" ")}
                      fill="none"
                      stroke="#475569"
                      strokeWidth="2.5"
                    />
                    {/* Current parameter indicator dot */}
                    {entropyP > 0 && entropyP < 1 && (
                      <circle
                        cx={entropyP * 200}
                        cy={70 - -(entropyP * Math.log2(entropyP) + (1 - entropyP) * Math.log2(1 - entropyP)) * 55}
                        r="5"
                        fill="#f59e0b"
                      />
                    )}
                    <line x1={entropyP * 200} y1="70" x2={entropyP * 200} y2="10" stroke="#f59e0b" strokeWidth="1" strokeDasharray="3" />
                  </svg>
                </div>

                <div className="space-y-1 bg-slate-900 border border-slate-800 px-3.5 py-2 rounded-xl">
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>Probability p(H): <span className="text-amber-400 font-bold">{entropyP.toFixed(2)}</span></span>
                    <span>Entropy H(X): <span className="text-emerald-400 font-bold">
                      {entropyP === 0 || entropyP === 1
                        ? "0 bits (Sure)"
                        : `-${(entropyP * Math.log2(entropyP) + (1 - entropyP) * Math.log2(1 - entropyP)).toFixed(3)} bits`}
                    </span></span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={entropyP}
                    onChange={(e) => setEntropyP(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1 bg-slate-800 rounded"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Real-World Case Study Sheet */}
          <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-4 space-y-1">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono text-[9px] text-amber-500">Case Study Application</h4>
            <p className="text-slate-350 text-[11px] leading-relaxed font-normal">{selectedConcept.caseStudy}</p>
          </div>

          {/* Mini concept quiz */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-col space-y-3.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-100 uppercase tracking-widest text-[9px] font-mono text-emerald-400">
              <GraduationCap className="w-4 h-4" /> Concept Verification Quiz
            </div>

            <p className="text-slate-300 font-semibold text-[11px] leading-snug">{selectedConcept.quiz.question}</p>

            <div className="grid grid-cols-1 gap-2">
              {selectedConcept.quiz.options.map((opt, idx) => {
                const isSelected = selectedAnswers[activeConcept] === idx;
                const isCorrect = selectedConcept.quiz.correct === idx;
                const quizShown = showQuizResult[activeConcept];

                let optionStyle = "border-slate-800 hover:border-slate-700 hover:bg-slate-900/40 text-slate-300";
                if (quizShown) {
                  if (isCorrect) optionStyle = "border-emerald-800 bg-emerald-950/30 text-emerald-200 font-bold";
                  else if (isSelected) optionStyle = "border-red-900 bg-red-950/30 text-red-200";
                } else if (isSelected) {
                  optionStyle = "border-amber-500 text-amber-400 font-bold";
                }

                return (
                  <button
                    key={idx}
                    disabled={quizShown}
                    onClick={() => handleQuizAnswer(activeConcept, idx)}
                    className={`w-full p-2.5 rounded-xl border text-left text-[11px] cursor-pointer transition-all flex justify-between items-center ${optionStyle}`}
                  >
                    <span>{opt}</span>
                    {quizShown && isCorrect && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                    {quizShown && isSelected && !isCorrect && <AlertCircle className="w-3.5 h-3.5 text-red-400" />}
                  </button>
                );
              })}
            </div>

            {showQuizResult[activeConcept] && (
              <p className="text-[10px] text-emerald-400/90 font-medium px-1 leading-normal">
                {selectedConcept.quiz.explanation}
              </p>
            )}
          </div>

          {/* Discuss with chat layout */}
          <button
            onClick={() => currentLauncherDiscuss(selectedConcept.title, selectedConcept.formula)}
            className="w-full flex items-center justify-center gap-2 bg-slate-950 border border-slate-800 hover:border-amber-500 text-slate-300 hover:text-amber-400 font-bold py-2.5 px-4 rounded-xl cursor-pointer transition-all text-xs"
          >
            <MessageSquare className="w-4 h-4" />
            Discuss {selectedConcept.title} deeply with Engiquery AI
          </button>
        </div>
      </div>
    </div>
  );
}
